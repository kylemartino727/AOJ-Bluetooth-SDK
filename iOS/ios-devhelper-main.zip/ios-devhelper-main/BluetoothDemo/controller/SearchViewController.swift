//
//  SearchViewController.swift
//  BluetoothDemo
//
//  Created by CCX on 2020/7/8.
//  Copyright © 2020 sky. All rights reserved.
//

import Foundation
import UIKit
import CoreData


class SearchViewController: UITableViewController, AHBluetoothStatusDelegate,SettingItemDelegate {
    
    
    //MARK: Properties
    var currentDevice: BTDeviceInfo?;
    
    var inputAlertView:UIAlertController?;
    var alertController:UIAlertController?;
    var scanResults = [ScanResults]();
    var isScanning = false;
    var scanningView : UIActivityIndicatorView?;
    var headerTitle : UILabel?;
    var pairMode:Int = 0x03; //默认的绑定方式为随机码
    
    @IBAction func startSearch(_ sender: UIBarButtonItem) {
        //check bluetooth status
        if(!(AHDevicePlugin.default()!.isBluetoothPowerOn)){
            updateHeaderTitle(title: Constants.Search.bluetoothUnavailable);
            //show alert view
            self.alertView(title: nil, msg: Constants.Search.bluetoothUnavailable);
            return;
        }
        self.isScanning = !self.isScanning;
        if(isScanning){
            //start scanning
            let stopItem = UIBarButtonItem.init(barButtonSystemItem: UIBarButtonItem.SystemItem.stop, target: self, action: #selector(startSearch(_:)));
            self.navigationController?.navigationBar.topItem?.setRightBarButton(stopItem, animated: true);
            //start searching
            self.startSearching(filter: self.toScanFilter(type: 0));
        }
        else{
            self.stopSearch();
        }
    }
    
    //数组排序
    @IBAction func scanFilter(_ sender: Any) {
//        self.scanResults.sort { (item1, item2) -> Bool in
//            item1.rssi > item2.rssi;
//        };
//        self.tableView.reloadData();
        self.showScanFilter();
    }
    
    override func viewDidLoad() {
        super.viewDidLoad();
        //view init
        self.viewInit();
        //register bluetooth state changed listener
        AHDevicePlugin.default()?.checkingBluetoothStatus(self);
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        if self.isMovingFromParent {
            print("SearchView.viewWillDisappear.....onBack...")
            self.scanResults.removeAll();
            self.tableView.reloadData();
            self.headerTitle?.text="";
            AHDevicePlugin.default().stopSearch();
        }
        super.viewWillDisappear(animated)
   
    }
    
 
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        //界面进入时，自动执行扫描
        self.autoSearch();
    }
    
    // MARK: - Table view data source
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1;
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return scanResults.count;
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "ScanResultsCell"
        guard let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? ScanResultsCell  else {
            fatalError("The dequeued cell is not an instance of MealTableViewCell.")
        }
        let item : ScanResults=scanResults[indexPath.row];
        cell.name.text=item.name;
        cell.broadcastId.text=item.manufacturerData;
        cell.rssi.text=String.init(format: "%d", item.rssi);
        cell.service.text=item.service;
        return cell;
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //tableView.deselectRow(at: indexPath, animated: true);
        self.stopSearch();
        let indexPath:IndexPath=self.tableView!.indexPathForSelectedRow!;
        let item:ScanResults=self.scanResults[indexPath.row];
        self.showDeviceinfo(device: item);
        //跳过绑定，直接添加
        //self.performSegue(withIdentifier: "connectIdentifier", sender: self);
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat{
        return 75;
    }
    
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 30;
    }
    
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return false;
    }
    
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?{
        let headerView : UIView?;
        headerView=UIView.init(frame: CGRect.init(x: 0, y: 0, width: tableView.bounds.size.width, height: 30));
        headerView?.backgroundColor=UIColor.groupTableViewBackground;
        //add sub view
        headerView?.addSubview(self.scanningView!);
        headerView?.addSubview(self.headerTitle!);
        return headerView;
    }
    
    // MARK: - Navigation
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        return false;
    }
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "connectIdentifier"){
            //Connect ViewController
            let connectVC = segue.destination as! ConnectViewController;
            let index:IndexPath?=self.tableView.indexPathForSelectedRow;
            let item:ScanResults?=self.scanResults[index!.row];
            let device:BTDeviceInfo = BTDeviceInfo.init();
            device.deviceName=item?.name;
            device.broadcastId=item?.broadcastId;
            device.manufacturerData=item?.manufacturerData;
            device.deviceType=BTDeviceType(rawValue: BTDeviceType.RawValue((item?.deviceType)!))!;
            device.protocolType = item?.protocolType;
            device.isRegistered = (item?.registerState == 0x01);
            //reset it
            connectVC.currentDevice=device;
            //save device
            connectVC.managedObject = StorageUtils.saveDevice(item: device);
            //clear
            AHDevicePlugin.default().setDevices(nil);
        }
    }
    
    func systemDidBluetoothStatusChange(_ bleState: CBManagerState) {
        DispatchQueue.main.async {
            if(bleState == CBManagerState.poweredOn){
                self.updateHeaderTitle(title: "");
            }
            else{
                self.updateHeaderTitle(title: Constants.Search.bluetoothUnavailable);
                self.scanningView?.stopAnimating();
                self.isScanning=false;
                let searchItem = UIBarButtonItem.init(barButtonSystemItem: UIBarButtonItem.SystemItem.search, target: self, action: #selector(self.startSearch(_:)));
                self.navigationController?.navigationBar.topItem?.setRightBarButton(searchItem, animated: true);
            }
        }
        
    }
    
    
    //MARK: SettingItemDelegate
    
    func didSelectRowAtItem(item: SettingItem) {
        self.dismiss(animated: true, completion: nil);
        if(item.action != nil){
            //trigger item's action
            item.action!(item,item.index);
        }
        else{
            print("item select \(item.title),index=\(item.index)");
        }
    }
    
    
    //MARK: Private Methods
    
    private func showPairMenu(){
        var pairModes = [SettingItem]();
        let item  = SettingItem.init(title: Constants.Pairing.pairWithRandomNum, type: .SingleChoice, index: 0x03, subTitle: nil,funcName: nil);
        let item2  = SettingItem.init(title: Constants.Pairing.pairWithAuto, type: .SingleChoice, index: 0x05, subTitle: nil,funcName: nil);
        let item3  = SettingItem.init(title: Constants.Pairing.pairIgnore, type: .SingleChoice, index: 2, subTitle: nil,funcName: nil);
        pairModes.append(item);
        pairModes.append(item2);
        pairModes.append(item3);
        let alert : UIAlertController = AlertUtils.showTableAlertView(title: Constants.Pairing.pairModeTitle, selectDelegate: self, dataSource: pairModes);
        self.present(alert, animated: true, completion: nil);
    }
    
    private func autoSearch(){
        if(!(AHDevicePlugin.default()!.isBluetoothPowerOn)){
            updateHeaderTitle(title: Constants.Search.bluetoothUnavailable);
            //show alert view
            self.alertView(title: nil, msg: Constants.Search.bluetoothUnavailable);
            return;
        }
        self.isScanning = !self.isScanning;
        //start scanning
        let stopItem = UIBarButtonItem.init(barButtonSystemItem: UIBarButtonItem.SystemItem.stop, target: self, action: #selector(startSearch(_:)));
        self.navigationController?.navigationBar.topItem?.setRightBarButton(stopItem, animated: true);
        //start searching
        let filter = BTScanFilter();
        self.startSearching(filter: filter);
    }

    private func stopSearch(){
        let startItem = UIBarButtonItem.init(barButtonSystemItem: UIBarButtonItem.SystemItem.search, target: self, action: #selector(startSearch(_:)));
        self.navigationController?.navigationBar.topItem?.setRightBarButton(startItem, animated: true);
        //stop searching
        AHDevicePlugin.default()?.stopSearch();
        self.scanningView!.stopAnimating();
        if(self.scanResults.count<=0){
            self.headerTitle?.text=Constants.Search.notDeviceFound;
        }
    }
    
    private func startSearching(filter:BTScanFilter){
        //clear
        self.scanResults.removeAll();
        self.tableView.reloadData();
        self.scanningView!.startAnimating();
        self.updateHeaderTitle(title: Constants.Search.scanning);
        //scan filter with device type
        AHDevicePlugin.default()?.searchDevice(filter, results: { (device) in
            let item : ScanResults? = ScanResults(device: device);
            if((item) != nil){
                DispatchQueue.main.async {
                    self.scanResults.append(item!);
                    self.tableView.insertRows(at: [IndexPath.init(row: self.scanResults.count-1, section: 0)], with: UITableView.RowAnimation.fade);
                    //update header
                    let msg:String=String.init(format: "%@%d", Constants.Search.scanResults,self.scanResults.count);
                    self.updateHeaderTitle(title: msg);
                }
            }
        })
    }
    
    private func viewInit(){
        //init scanning view
        self.scanningView = UIActivityIndicatorView.init(style: UIActivityIndicatorView.Style.white);
        scanningView?.color=UIColor.brown;
        scanningView?.frame=CGRect.init(x: 5, y: 6, width: 20, height: 20);
        //init header title view
        self.headerTitle=UILabel.init(frame: CGRect.init(x: self.tableView.bounds.width-200-5, y: 6, width: 200, height: 20));
        self.headerTitle?.textColor=UIColor.brown;
        self.headerTitle?.font=UIFont.boldSystemFont(ofSize: 13);
        self.headerTitle?.text="";
        self.headerTitle?.textAlignment=NSTextAlignment.right;
        
        //check bluetooth status
        if(!(AHDevicePlugin.default()!.isBluetoothPowerOn)){
            updateHeaderTitle(title: Constants.Search.bluetoothUnavailable);
            //show alert view
            self.alertView(title: nil, msg: Constants.Search.bluetoothUnavailable);
            return;
        }
    }
    
    private func updateHeaderTitle(title:String){
        self.headerTitle?.text=title;
    }
    
    private func alertView(title:String?,msg:String?){
        let alert : UIAlertController = AlertUtils.showPrompt(title: title, msg: msg, cancelBtn: false);
        self.present(alert, animated: true, completion: nil);
    }
    
    private func toScanFilter(type:Int) -> BTScanFilter{
        let filter = BTScanFilter();
        if(type == BTDeviceType.thermometer.rawValue){
            filter.scanTypes = [BTDeviceType.thermometer.rawValue];
        }
        else if(type == BTDeviceType.oximeter.rawValue){
            filter.scanTypes = [BTDeviceType.oximeter.rawValue];
        }
        else if(type == BTDeviceType.bloodPressureMeter.rawValue){
            filter.scanTypes = [BTDeviceType.bloodPressureMeter.rawValue];
        }
        else if(type == BTDeviceType.digitalThermometer.rawValue) {
            filter.scanTypes = [BTDeviceType.digitalThermometer.rawValue];
        }
        else {
            filter.scanTypes = [BTDeviceType.digitalThermometer.rawValue,
                                BTDeviceType.thermometer.rawValue,
                                BTDeviceType.oximeter.rawValue,
                                BTDeviceType.bloodPressureMeter.rawValue];
        }
        return filter;
        
    }
    
    /**
     * 扫描过滤
     */
    private func showScanFilter() -> Void{
        self.stopSearch();
        var options = [SettingItem]();
        Constants.ScanFilter.allCases.forEach { (str) in
            let title = String.init(format: "%@", str.rawValue);
            let num = Constants.ScanFilter.allCases.firstIndex(of: str);
            let item = SettingItem.init(title: title, type: .QueryCmd, index: num!, subTitle: nil) {(item,value) in
                 print("scan filter\(item.title),index=\(item.index)");
                self.startSearching(filter: self.toScanFilter(type: item.index));
            }
            options.append(item);
        }
        AlertUtils.showSelectView(title: "Scan Filter", selectDelegate: self, dataSource: options, controler: self);
    }
    
    private func showDeviceinfo(device: ScanResults)->Void{
        DispatchQueue.main.async {
            var msg:String = "";
            var str :String = String();
            str.append("Device Name:\(device.name ?? "#")\n");
            str.append("Device Type:\(device.deviceType)\n");
            str.append("Broadcast ID:\(device.broadcastId ?? "#")\n");
            str.append("Manufacturer Data:\(device.manufacturerData ?? "#")\n");
            msg = str;
            let alertView = AlertUtils.showPrompt(title: "Device Info", msg: msg, cancelBtn: false) { (action) in
                //push to connect view controller
                self.performSegue(withIdentifier: "connectIdentifier", sender: self);
            }
            self.present(alertView, animated: true, completion: nil);
        }
    }
    
    //数据测试
    private func insertTestData(){
        for index in 0..<9{
            let device:BTDeviceInfo = BTDeviceInfo.init();
            device.deviceName="testName";
            device.broadcastId=String.init(format: "%@%d", "13213123dd",index);
            device.manufacturerData=String.init(format: "%@%d", "13213123dd",index);
            device.deviceType=BTDeviceType.oximeter;
            device.rssi=0;
            let item:ScanResults?=ScanResults(device: device);
            self.scanResults.append(item!);
        }
    }
    
    // MARK: Private
    //FADF0AEC-F6DC-4648-8497-CC6FEF2457C5
    private func pairDevice(device:BTDeviceInfo){
        self.loadingView(title: "", msg: Constants.Pairing.title);
        self.currentDevice=device;
        //stop search
        AHDevicePlugin.default()?.stopSearch();
        //pair device
        AHDevicePlugin.default()?.pairDevice(device, delegate: self);
    }
    
    private func loadingView(title:String?,msg:String?,action: (() -> Void)? = nil){
        self.alertController = AlertUtils.showLoadingView(title: title, msg: msg,cancelBtn: true) { (cancelAction) in
            if(self.currentDevice != nil){
                print("cancel device pairing.\(self.currentDevice!)");
                AHDevicePlugin.default()?.cancelDevicePairing(self.currentDevice!);
            }
        };
        self.present(self.alertController!, animated: true, completion: action);
    }
    
    private func sendPairMessage(msg:BTDevicePairMsg){
       
    }
}

extension SearchViewController : AHDevicePairingDelegate
{
    func bleDevice(_ device: BTDeviceInfo!, didPairStateChanged state: BTPairState) {
        DispatchQueue.main.async {
            print("UI-didPairStateChanged=\(state.rawValue)");
        
        }
    }
    
    func bleDevice(_ lsDevice: BTDeviceInfo!, didPairMessageUpdate pairMsg: BTDevicePairMsg!) {
        DispatchQueue.main.async {
            print("UI-didPairMessageUpdate=\(pairMsg.cmd.rawValue)");
        }
    }
}
