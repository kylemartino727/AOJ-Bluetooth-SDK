//
//  BindingViewController.swift
//  BluetoothDemo
//
//  Created by CCX on 2020/7/21.
//  Copyright © 2020 sky. All rights reserved.
//

import UIKit
import AVFoundation

protocol QrcodeResutlsDelegate {
    
    func qrcodeDecodeResults(mac:String,code:String) ;
}


class BindingViewController: UIViewController,UIAlertViewDelegate,QrcodeResutlsDelegate,AHDevicePairingDelegate {
    
    var currentDevice:BTDeviceInfo?;
    var alertController:UIAlertController?;
    var randomCode:String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "qrcodeIdentifier"){
            let segueView = segue.destination as! QrcodeViewController;
            segueView.qrcodeDelegate=self;
        }
    }
    
    // MARK: QrcodeResutlsDelegate
    
    func qrcodeDecodeResults(mac: String, code: String) {
        self.pairDevice(mac: mac, code: code);
    }
    
    // MARK: LSDevicePairingDelegate
    
    func bleDevice(_ device: BTDeviceInfo!, didPairStateChanged state: BTPairState) {
        print("UI-didPairStateChanged=\(state.rawValue)");
        DispatchQueue.main.async {
            self.dismiss(animated: true) {
                let msg:String=(state == BTPairState.success) ? "绑定成功":"绑定失败";
                let alertView = AlertUtils.showPrompt(title: "Pair Results", msg: msg, cancelBtn: false) { (action) in
                    //返回上一级视图
                    let managedObj = StorageUtils.saveDevice(item: device!);
                    //push to connect view controller
                    let connectView = self.storyboard!.instantiateViewController(withIdentifier: "connectViewIdentifier") as? ConnectViewController;
                    connectView!.currentDevice = device;
                    connectView!.managedObject = managedObj;
                    self.navigationController?.pushViewController(connectView!, animated: true);
                }
                self.present(alertView, animated: true, completion: nil);
            }
        }
    }
    
    func bleDevice(_ lsDevice: BTDeviceInfo!, didPairMessageUpdate pairMsg: BTDevicePairMsg!) {
        print("UI-didPairMessageUpdate=\(pairMsg.cmd.rawValue)");
    
    }
    
    
    // MARK: Private
    //FADF0AEC-F6DC-4648-8497-CC6FEF2457C5
    private func pairDevice(mac:String,code:String){
        print("try to pair device=\(mac),code=\(code)");
    
        self.loadingView(title: "", msg: Constants.Pairing.title);
        self.randomCode=code;
        //search device with mac
        AHDevicePlugin.default()?.searchDevice(nil, results: { (scanResults) in
            if(scanResults != nil && scanResults?.broadcastId != nil
                && scanResults?.broadcastId!.uppercased() == mac.uppercased()){
                //stop search
                AHDevicePlugin.default()?.stopSearch();
                self.currentDevice=scanResults;
                if(AHDevicePlugin.default()?.syncStatus == BTManagerState.syncing.rawValue){
                    AHDevicePlugin.default()?.stopAutoConnect();
                }
                //pair device
                AHDevicePlugin.default()?.pairDevice(scanResults!, delegate: self);
            }
        })
    }
    
    private func loadingView(title:String?,msg:String?){
        self.alertController = AlertUtils.showLoadingView(title: title, msg: msg, cancelBtn: true) { (cancelAction) in
            if(self.currentDevice != nil){
                print("cancel device pairing.\(self.currentDevice!)");
                AHDevicePlugin.default()?.cancelDevicePairing(self.currentDevice!);
            }
        };
        self.present(self.alertController!, animated: true, completion: nil);
    }
    
    
    private func sendPairMessage(msg:BTDevicePairMsg){

    }
}
