//
//  ConnectViewController.swift
//  BluetoothDemo
//
//  Created by CCX on 2020/7/6.
//  Copyright © 2020 sky. All rights reserved.
//

import Foundation
import UIKit
import CoreData

protocol SettingItemDelegate {
    
    func didSelectRowAtItem(item:SettingItem) ;
}

class ConnectViewController: UIViewController{
    
    //MARK: Properties
    @IBOutlet weak var dataLabel: UILabel!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var stateLabel: UILabel!
    @IBOutlet weak var loadingView: UIActivityIndicatorView!
    @IBOutlet weak var dataTextView: UITextView!
    
    @IBOutlet weak var respView: UIView!
    @IBOutlet weak var respLabel: UILabel!
    
    var currentDevice:BTDeviceInfo?;
    var updatingView:UIAlertController?;
    var newDataCount:Int = 0x00;
    var timer : Timer? ;
    var managedObject : NSManagedObject?;
    var startTime : TimeInterval?;
    var wfFilePath : URL?;
    var tempStatus : AHTempStatus?;

    @IBOutlet weak var fileBtn: UIBarButtonItem!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fileBtn.isEnabled = false;
        fileBtn.tintColor = UIColor.clear;
        titleLabel.text=String.init(format: "%@[%@]", currentDevice!.deviceName!,currentDevice!.broadcastId!);
        //init
        self.newDataCount=0;
        self.dataTextView.text="";
        self.dataLabel.isHidden=true;
        self.stateLabel.textColor=UIColor.gray;
   
        //register bluetooth state changed
        AHDevicePlugin.default()?.checkingBluetoothStatus(self);
        
        //connect device
        self.connectDevice();
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        print("viewWillAppear >>>>>>");
    
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        if self.isMovingFromParent {
            self.dataTextView.text="";
            print("viewWillDisappear.....onBack...")
            AHDevicePlugin.default()?.stopAutoConnect();
        }
        super.viewWillDisappear(animated);
    }
    
    @IBAction func update(_ sender: UIBarButtonItem) {
        var options = [SettingItem]();
        Constants.FileUpdateItem.allCases.forEach { (str) in
            let item = SettingItem.init(title: str.rawValue, type: .Title, index:0x00, subTitle: nil) {(item,value) in
                if(value != nil){
                    let fileType = self.parseUpdateType(type:item.title);
                    self.selectFiles(modelName: self.currentDevice!.modelNumber!, type:fileType);
                }
            }
            options.append(item);
        }
        let alert : UIAlertController = AlertUtils.showTableAlertView(title: Constants.Menu.keyUpdateType, selectDelegate: self, dataSource: options);
        self.present(alert, animated: true, completion: nil);
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        return self.initMenu();
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "settingsIdentity"){
            //Setting ViewController
            let settingVC = segue.destination as! SettingsViewController;
            settingVC.currentDevice=self.currentDevice;
            settingVC.mode = self.tempStatus?.mode;
        }
    }
    
    //MARK: Device Menu
    
    ///默认功能菜单
    private func initMenu() -> Bool{
        var menus = [MenuItem]();
        menus.append(MenuItem.init(name: Constants.Menu.keyConnect, funcName: {
            ///连接
            self.loadingView.isHidden = false;
            self.loadingView.startAnimating();
            self.stateLabel.text=Constants.Connect.keyConnecting;
            AHDevicePlugin.default()?.startAutoConnect(self);
        }));
        menus.append(MenuItem.init(name: Constants.Menu.keyDisconnect, funcName: {
            ///断开
            self.disconnect();
        }));
        menus.append(MenuItem.init(name: Constants.Menu.keyShareLog, funcName: {
            /// log 日志分享
            self.sharelog();
        }));
        menus.append(MenuItem.init(name: Constants.Menu.keyClearLog, funcName: {
            /// 清屏
            self.dataTextView.text = "";
        }));
        menus.append(MenuItem.init(name: Constants.Menu.keySetting, funcName: {
            //push to Settings view controller
            self.performSegue(withIdentifier: "settingsIdentity", sender: self);
        }));
        AlertUtils.showActionSheet(menus: menus, title: Constants.Menu.keyTitle, view: self);
        return false;
    }
    
    //MARK: Private Methods

    ///断开连接
    private  func disconnect(){
        self.loadingView.isHidden=true;
        self.loadingView.stopAnimating();
        self.stateLabel.textColor=UIColor.gray;
        self.stateLabel.text=Constants.Connect.keyNotConnected;
        AHDevicePlugin.default()?.stopAutoConnect();
    }
    

    ///日志分享
    private func sharelog(){
        let files = (AHDevicePlugin.default()?.exportLogFiles(self.currentDevice?.broadcastId));
        if(files != nil){
            let list = files! as Array;
            var fileItems = [SettingItem]();
            list.forEach { (item) in
                let url = URL.init(fileURLWithPath: item as! String);
                print("item of file\(url.pathComponents.last ?? "no value")");
                //to file item
                let fileName = String.init(format: "%@", url.pathComponents.last!);
                let fileItem = FileItem(fileName: fileName,filePath: item as! String);
                let title = "";
                let settingItem  = SettingItem.init(title: title, type: .Share, index: 0, subTitle: fileName,funcName: nil);
                //set filepath
                settingItem.filePath = fileItem.path;
                fileItems.append(settingItem);
            }
            let alert : UIAlertController = AlertUtils.showTableAlertView(title: Constants.SettingItem.keyShareLog, selectDelegate: self, dataSource: fileItems);
            self.present(alert, animated: true, completion: nil);
            //ShareUtils.shareFile(controller: self, filePath:list.first as! String);
        }
        else{
            self.alertView(title: Constants.FileUpdate.notFileFound, msg: nil);
        }
    }
    
    ///打印输出
    private func appendOutputText(msg:String){
        DispatchQueue.main.async {
            if #available(iOS 11, *){
                self.dataTextView.insertText(" ");
                self.dataTextView.insertText(msg);
                self.dataTextView.insertText("\n");
            }
            else{
                self.dataTextView.text=String.init(format: "  %@  %@\n", self.dataTextView.text,msg);
            }
        }
    }
    
    private func alertView(title:String?,msg:String?){
        let alert : UIAlertController = AlertUtils.showPrompt(title: title, msg: msg, cancelBtn: false);
        self.present(alert, animated: true, completion: nil);
    }
    
    /**
     * 连接设备
     */
    private func connectDevice(){
        if(!(AHDevicePlugin.default()!.isBluetoothPowerOn)){
            self.alertView(title: nil, msg: Constants.Search.bluetoothUnavailable);
            self.systemDidBluetoothStatusChange(CBManagerState.poweredOff);
            return;
        }
        self.loadingView.startAnimating();
        //check manager status
        if(AHDevicePlugin.default()?.managerStatus == BTManagerState.syncing){
            //waiting for firmware upgrading
            return;
        }
        else{
            //add target device
            AHDevicePlugin.default()?.addDevice(self.currentDevice);
            AHDevicePlugin.default()?.startAutoConnect(self);
        }
    }
    

    
    /**
     * 推送设置
     */
    private func pushSetting(setting:BTDeviceSetting){
        AHDevicePlugin.default()?.push(setting, toDevice: self.currentDevice!, response: { (state, error, data) in
            DispatchQueue.main.async {
                var msg = String.init(format: Constants.Setting.titleFailed, error);
                if(state){
                    msg = Constants.Setting.titleSuccess;
                }
                //display toast view
                self.respView.isHidden = false;
                self.respLabel.isHidden = false;
                self.respLabel.text=msg;
                //delay to dismiss
                self.timer = Timer.scheduledTimer(timeInterval: 1, target: self,
                                                  selector: #selector(self.dismissToastView(timer:)), userInfo: nil, repeats: false)
            };
        });
    }
    
    @objc private func dismissToastView(timer: Timer) {
        self.respLabel.isHidden = true;
        self.respView.isHidden = true;
    }
    
    
    /**
     * 文件选择
     */
    private func selectFiles(modelName:String,type:ItemType){
        if(self.currentDevice?.modelNumber == nil){
            self.alertView(title: Constants.FileUpdate.keyUpdateFailed, msg: Constants.FileUpdate.notConnect);
            return ;
        }
        var filesItem = [SettingItem]();
        //获取固件文件 self.currentDevice!.modelNumber
        var files = ShareUtils.firmwareFiles(model: modelName) ?? [FileItem]();
        if(type == .Dial){
            files = ShareUtils.dialFiles(model: modelName) ?? [FileItem]();
        }
        else if(type == .PushFile || type == .SyncFile){
            files = ShareUtils.dataFiles(model: modelName) ?? [FileItem]();
        }
        if(files.count <= 0){
            let alertView = AlertUtils.showPrompt(title: nil, msg: Constants.FileUpdate.notFileFound, cancelBtn: false);
            self.present(alertView, animated: true, completion: nil);
            return ;
        }
        for index in 0..<files.count {
            let file : FileItem = files[index];
            let title = file.firmwareVersion;
            let item  = SettingItem.init(title: title, type: type, index: 0, subTitle: file.name,funcName: nil);
            //set filepath
            item.filePath = file.path;
            filesItem.append(item);
        }
        if(type == .PushFile || type == .SyncFile){
            //self.showPushFileView(files: files);
        }
        else{
            let alert : UIAlertController = AlertUtils.showTableAlertView(title: Constants.FileUpdate.fileSelect, selectDelegate: self, dataSource: filesItem);
            self.present(alert, animated: true, completion: nil);
        }
    }
    
    
    /**
     * 更新固件
     */
    private func updateFirmware(fileUrl:URL)
    {
       
    }

    /**
     * 获取更新类型
     */
    private func parseUpdateType(type:String) -> ItemType{
        if(Constants.FileUpdateItem.Firmware.rawValue.caseInsensitiveCompare(type) == .orderedSame){
            return .File;
        }
        else{
            return .Text;
        }
    }

}



//MARK: SettingItemDelegate

extension ConnectViewController : SettingItemDelegate
{
    func didSelectRowAtItem(item: SettingItem) {
        self.dismiss(animated: true, completion: nil);
        if(item.type == .File && item.filePath != nil){
            //firmware update
            let url = URL.init(fileURLWithPath: item.filePath!);
            //self.updateFirmware(fileUrl: url);
            //share test
            return;
        }
        else if(item.type == .Share && item.filePath != nil){
            //日志分享
            ShareUtils.shareFile(controller: self, filePath:item.filePath!);
        }
        else if(item.action != nil){
            //trigger item's action
            item.action!(item,item.index);
        }
        else{
            print("item select \(item.title),index=\(item.index)");
        }
    }
}

// MARK: LSBluetoothStateDelegate

extension ConnectViewController : AHBluetoothStatusDelegate
{
    func systemDidBluetoothStatusChange(_ bleState: CBManagerState) {
        DispatchQueue.main.async {
            if(bleState == CBManagerState.poweredOn){
                self.stateLabel.text=Constants.Connect.keyConnecting;
                self.stateLabel.textColor=UIColor.gray;
                self.loadingView.isHidden=false;
                self.loadingView.startAnimating();
                self.dataTextView.text="";
                //connect
                self.connectDevice();
            }
            else{
                self.stateLabel.text=Constants.Search.bluetoothUnavailable;
                self.stateLabel.textColor=UIColor.red;
                self.loadingView.stopAnimating();
                self.loadingView.isHidden=true;
            }
        }
    }
}


// MARK: BTDeviceDataDelegate

extension ConnectViewController : AHDeviceDataDelegate
{
    /**
     * 连接状态更新
     */
    func bleDevice(_ device: BTDeviceInfo!, didConnectStateChanged connectState: BTConnectState) {
        DispatchQueue.main.async {
            var stateStr:String=Constants.Connect.keyConnecting;
            if(connectState == BTConnectState.success){
                stateStr=Constants.Connect.keyConnected;
                self.stateLabel.text=stateStr;
                self.stateLabel.textColor=UIColor.systemBlue;
                self.loadingView.stopAnimating();
                self.loadingView.isHidden=true;
                self.dataLabel.isHidden=false;
                self.dataLabel.text="";
            }
            else if(AHDevicePlugin.default()?.syncStatus == BTManagerState.syncing.rawValue ){
                self.stateLabel.textColor=UIColor.gray;
                self.dataLabel.isHidden=true;
                self.loadingView.isHidden=false;
                self.stateLabel.text=stateStr;
                self.loadingView.startAnimating();
            }
            else{
                self.loadingView.isHidden=true;
                self.loadingView.stopAnimating();
                self.stateLabel.textColor=UIColor.gray;
                self.stateLabel.text=Constants.Connect.keyNotConnected;
            }
        }
    }
    
    
    /**
     * 设备信息更新
     */
    func bleDeviceDidInformationUpdate(_ device: BTDeviceInfo!) {
        self.currentDevice=device;
        DispatchQueue.main.async {
            self.appendOutputText(msg: String.init(format: "#%@{", "Device Information"));
            if(device.deviceId != nil){
                self.appendOutputText(msg: String.init(format: "deviceId=%@", device.deviceId!));
            }
            if(device.deviceSn != nil){
                self.appendOutputText(msg: String.init(format: "deviceSn=%@", device.deviceSn!));
            }
            if(device.firmwareVersion != nil){
                self.appendOutputText(msg: String.init(format: "firmware=%@", device.firmwareVersion!));
            }
            if(device.hardwareVersion != nil){
                self.appendOutputText(msg: String.init(format: "hardware=%@", device.hardwareVersion!));
            }
            if(device.timezone != nil){
                self.appendOutputText(msg: String.init(format: "timeZone=%@", device.timezone!));
            }
            if(device.protocolType != nil){
                self.appendOutputText(msg: String.init(format: "protocol=%@", device.protocolType!));
            }
            if(device.modelNumber != nil){
                self.appendOutputText(msg: String.init(format: "modelNumber=%@", device.modelNumber!));
            }
            self.appendOutputText(msg: String.init(format: "userNumber=%d", device.deviceUserNumber));
            self.appendOutputText(msg: "}");
        }
    }
    
    
    /**
     * 设备测量过程状态或错误等通知信息回调
     */
    func bleDevice(_ device: BTDeviceInfo!, didDataUpdateNotification obj: BTDeviceData!) {
        DispatchQueue.main.async {
            self.newDataCount += 1;
            self.dataLabel.text=String.init(format: "%d News", self.newDataCount);
            //source data
            if(obj.srcData != nil && obj.srcData?.hexadecimal != nil){
                let str:String = String.init(format: "\nsrcData=%@\n",obj.srcData!.hexadecimal);
                self.appendOutputText(msg: str);
            }
            //log class name
            let className:String=type(of: obj).description();
            self.appendOutputText(msg: String.init(format: "#%@{", className));
            //log class properties
            for (key, value) in obj.toString() {
                let dataStr:String=String.init(format: "%@=%@", key as CVarArg,value as! CVarArg);
                self.appendOutputText(msg: dataStr);
            }
            if(obj.utc > 0 && obj.measureTime != nil){
                //data utc
                let utcStr:String = String.init(format: "utc=%d", obj.utc);
                self.appendOutputText(msg: utcStr);
                //measure time
                let timeStr:String = String.init(format: "measureTime=%@", obj.measureTime!);
                self.appendOutputText(msg: timeStr);
            }
        
            //end
            self.appendOutputText(msg: "}");
            if(obj is AHTempStatus){
                self.tempStatus = obj as! AHTempStatus;
            }
        };
    }

}

