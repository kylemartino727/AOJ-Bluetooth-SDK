//
//  SettingItemCell.swift
//  BluetoothDemo
//
//  Created by CCX on 2020/7/31.
//  Copyright © 2020 sky. All rights reserved.
//

import UIKit

class SettingItemCell: UITableViewCell {
    
    var item : SettingItem!;
    
    @IBOutlet weak var textField: UITextField!
    
    
    @IBOutlet weak var titleLabel: UILabel!
    
    
    @IBOutlet weak var stateButton: UISwitch!
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier);
        self.autoresizingMask = .init(arrayLiteral: .flexibleHeight,.flexibleWidth);
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder);
    }
    
    override func awakeFromNib() {
        super.awakeFromNib();
        self.autoresizingMask = .init(arrayLiteral: .flexibleHeight,.flexibleWidth);
        self.textField.delegate=self;
        self.stateButton.addTarget(self, action:#selector(switchChanged), for: .valueChanged);
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
    @objc func switchChanged(mySwitch: UISwitch){
        if(item.action != nil){
            item.action!(item,mySwitch.isOn);
        }
    }
}

extension SettingItemCell : UITextFieldDelegate{
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if(item == nil){
            return true;
        }
        print("textFieldShouldReturn = \(textField.text ?? "no input value"),item=\(item.title)");
        textField.resignFirstResponder();
        if(item != nil && item.type == .NumbersAndPunctuation){
         if(!self.checkTimeFormat(str: textField.text)){
                textField.text = "";
            }
        }
        if(item != nil && item.action != nil && textField.text != nil){
            item.action!(item,textField.text);
        }
        return true;
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if(item == nil){
            return ;
        }
        print("textFieldDidEndEditing \(textField.text ?? "no input value"),item=\(item.title)");
        if(item != nil && item.type == .NumbersAndPunctuation){
            if(!self.checkTimeFormat(str: textField.text)){
                textField.text = "";
            }
        }
        if(item != nil && item.action != nil && textField.text != nil){
            item.action!(item,textField.text);
        }
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        print("textFieldShouldBeginEditing....");
        if(item != nil && item.type == .SingleChoice){
            textField.resignFirstResponder();
            let picker = UIPickerView();
            picker.delegate = self ;
            picker.dataSource = self;
            textField.inputView =  picker;
            picker.selectRow(0, inComponent: 0, animated: false);
            textField.text = item.choiceItems[0];
        }
        return true;
    }
    
    func checkTimeFormat(str:String?) -> Bool{
        if(str == nil){
            return false;
        }
        let reg = "^(0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$";
        let pred = NSPredicate.init(format: "SELF MATCHES %@", reg);
        return pred.evaluate(with: textField.text);
    }
}

extension SettingItemCell : UIPickerViewDelegate,UIPickerViewDataSource{
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView( _ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return self.item.choiceItems.count;
    }

    func pickerView( _ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return self.item.choiceItems[row];
    }

    func pickerView( _ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.textField.text = self.item.choiceItems[row];
    }
}

