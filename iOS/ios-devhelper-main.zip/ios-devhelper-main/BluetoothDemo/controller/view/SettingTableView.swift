//
//  SettingTableView.swift
//  BluetoothDemo
//
//  Created by CCX on 2020/7/31.
//  Copyright © 2020 sky. All rights reserved.
//

import UIKit

class SettingTableView: UITableView,UITableViewDataSource,UITableViewDelegate {
    
    var itemSelectDelegate: SettingItemDelegate?
    
    override init(frame: CGRect, style: UITableView.Style) {
        super.init(frame: frame, style: style);
        self.dataSource = self;
        self.delegate = self;
        self.tag=12;
        self.tableFooterView = UIView.init(frame: CGRect.zero);
        self.separatorStyle=UITableViewCell.SeparatorStyle.singleLine;
        self.showsVerticalScrollIndicator=true;
        self.allowsSelection=false;
        self.register(UINib.init(nibName: "SettingItemCell", bundle: nil), forCellReuseIdentifier: "SettingItemCellIdentifier");
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    var dataArray = [SettingItem]();
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.dataArray.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "SettingItemCellIdentifier";
        guard let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? SettingItemCell  else {
            fatalError("The dequeued cell is not an instance of MealTableViewCell.")
        }
        let item :SettingItem = self.dataArray[indexPath.row] ;
        cell.item=item;
        cell.titleLabel.text = item.title;
        cell.textField.clearButtonMode = .whileEditing ;

        if(item.subTitle.description.count > 0){
            cell.textField.placeholder = item.subTitle;
        }
        //cell.textField.delegate=self;
        if(item.type == .Switch){
            cell.stateButton.isHidden=false;
        }
        else if(item.type == .Text){
            cell.textField.isHidden = false;
            cell.textField.keyboardType = .default;
        }
        else if(item.type == .Number){
            cell.textField.isHidden = false;
            cell.textField.keyboardType = .decimalPad;
        }
        else if(item.type == .NumbersAndPunctuation){
            cell.textField.isHidden = false;
            cell.textField.keyboardType = .numbersAndPunctuation;
        }
        else if(item.type == .SingleChoice){
            cell.textField.isHidden = false;
            cell.textField.clearButtonMode = .never;
        }
        return cell;
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60;
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    
}


