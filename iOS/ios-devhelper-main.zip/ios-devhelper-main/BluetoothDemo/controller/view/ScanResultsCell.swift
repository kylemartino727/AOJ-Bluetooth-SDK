//
//  ScanResultsCell.swift
//  BluetoothDemo
//
//  Created by CCX on 2020/7/8.
//  Copyright © 2020 sky. All rights reserved.
//

import UIKit

class ScanResultsCell: UITableViewCell {

    @IBOutlet weak var name: UILabel!
    
    @IBOutlet weak var service: UILabel!
    
    @IBOutlet weak var broadcastId: UILabel!
    
    @IBOutlet weak var rssi: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
