//
//  CustomTableView.swift
//  BluetoothDemo
//
//  Created by CCX on 2020/7/14.
//  Copyright © 2020 sky. All rights reserved.
//

import UIKit


class CustomTableView: UITableView,UITableViewDataSource,UITableViewDelegate {
    
    var itemSelectDelegate: SettingItemDelegate?
    
    override init(frame: CGRect, style: UITableView.Style) {
        super.init(frame: frame, style: style);
        self.dataSource = self;
        self.delegate = self;
        self.tag=12;
        self.tableFooterView = UIView.init(frame: CGRect.zero);
        self.separatorStyle=UITableViewCell.SeparatorStyle.singleLine;
        self.showsVerticalScrollIndicator=true;
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    var dataArray = [SettingItem]();
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.dataArray.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell: UITableViewCell? = tableView.dequeueReusableCell(withIdentifier: "fileCell");
        if(cell == nil){
            cell=UITableViewCell.init(style:UITableViewCell.CellStyle.subtitle , reuseIdentifier: "fileCell");
        }
        let item :SettingItem = self.dataArray[indexPath.row] ;
        cell?.textLabel?.text = item.title;
        if(item.type == .File || item.type == .Dial || item.type == .Share){
            cell?.textLabel?.textColor=UIColor.red;
            cell?.detailTextLabel?.text = item.subTitle;
        }
        return cell!;
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50;
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true);
        let item :SettingItem = self.dataArray[indexPath.row] ;
        if(self.itemSelectDelegate != nil){
            self.itemSelectDelegate?.didSelectRowAtItem(item: item);
        }
    }
    
}
