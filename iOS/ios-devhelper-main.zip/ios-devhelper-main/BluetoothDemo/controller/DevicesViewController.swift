//
//  MyDevices.swift
//  BluetoothDemo
//
//  Created by CCX on 2020/7/3.
//  Copyright © 2020 sky. All rights reserved.
//

import Foundation
import UIKit
import CoreData

class DevicesViewController: UITableViewController {
    
    var pairedDevices: [NSManagedObject] = [];
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    override func viewWillAppear(_ animated: Bool){
        super.viewWillAppear(animated);
        print("DeviceViewController -> viewDidAppear ...");
        self.fetchData();
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    // MARK: - Table view data source
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 2;
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (section>0 ? pairedDevices.count:1);
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if(indexPath.section == 0){
            //section 0
            var cell: UITableViewCell? = tableView.dequeueReusableCell(withIdentifier: "versionCell");
            if(cell == nil){
                cell=UITableViewCell.init(style:UITableViewCell.CellStyle.value1 , reuseIdentifier: "versionCell");
            }
            cell?.textLabel?.text = "App Version";
            // cell.accessoryType=UITableViewCell.AccessoryType.none;
            //cell.selectionStyle=UITableViewCell.SelectionStyle.none;
            let buildStr : String = (Bundle.main.infoDictionary?["CFBundleVersion"] as? String)!;
            let versionStr : String = (Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String)!;
            cell?.detailTextLabel?.text = String.init(format: "%@-build %@", versionStr,buildStr);
            return cell!;
        }
        else{
            var cell: UITableViewCell? = tableView.dequeueReusableCell(withIdentifier: "deviceCell");
            if(cell == nil){
                cell=UITableViewCell.init(style:UITableViewCell.CellStyle.subtitle , reuseIdentifier: "deviceCell");
            }
            let device=self.pairedDevices[indexPath.row];            
            cell?.textLabel?.text = device.value(forKeyPath: Constants.PairedDevice.keyName) as? String;
            cell?.detailTextLabel?.text=device.value(forKeyPath: Constants.PairedDevice.keyBroadcastId) as? String;
            cell?.imageView?.image=UIImage.init(named: "bluetooth.png");
            //调整图片大小
            cell?.imageView?.layer.cornerRadius = 15;
            let itemSize = CGSize(width:30, height:30);
            UIGraphicsBeginImageContextWithOptions(itemSize, false, UIScreen.main.scale);
            let imageRect = CGRect(x:0, y:0, width: itemSize.width, height: itemSize.height);
            cell?.imageView?.image?.draw(in: imageRect);
            cell?.imageView?.image = UIGraphicsGetImageFromCurrentImageContext();
            UIGraphicsEndImageContext();
            return cell!;
        }
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true);
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60;
    }
    
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return (section>0 ? 5:0);
    }
    
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return indexPath.section==1;
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            let removeItme:NSManagedObject=self.pairedDevices[indexPath.row];
            //remove
            StorageUtils.removeData(item: removeItme);
            self.pairedDevices.remove(at: indexPath.row);
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }
    
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?{
        let headerView = UIView();
        headerView.backgroundColor = UIColor.gray;
        return headerView;
    }
    
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "addDeviceIdentifier"){
            //AddDevice ViewController
            
        }
        else if(segue.identifier == "connectIdentifier"){
            //Connect ViewController
            let index:IndexPath?=self.tableView.indexPathForSelectedRow;
            let item:NSManagedObject?=self.pairedDevices[index!.row];
            let connectVC = segue.destination as! ConnectViewController;
            let device:BTDeviceInfo = BTDeviceInfo.init();
            device.broadcastId=item!.value(forKeyPath: Constants.PairedDevice.keyBroadcastId) as? String;
            device.macAddress=item!.value(forKeyPath: Constants.PairedDevice.keyMacAddress) as? String;
            device.deviceType=BTDeviceType(rawValue: BTDeviceType.RawValue((item!.value(forKeyPath: Constants.PairedDevice.keyDeviceType) as? Int)!))!;
            device.protocolType=item!.value(forKeyPath: Constants.PairedDevice.keyProtocolType) as? String;
            device.deviceName=item!.value(forKeyPath: Constants.PairedDevice.keyName) as? String;
            device.deviceUserNumber=(item?.value(forKeyPath: Constants.PairedDevice.keyUserNumber) as? UInt)!;
            connectVC.currentDevice=device;
            connectVC.managedObject = item;
        }
    }
    
    private func fetchData(){
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return ;
        }
        let managedContext = appDelegate.persistentContainer.viewContext;
        let fetchRequest =  NSFetchRequest<NSManagedObject>(entityName:Constants.CoreData.modelName);
        do {
            self.pairedDevices = try managedContext.fetch(fetchRequest);
            //refresh
            self.tableView.reloadData();
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
    }
}
    

