//
//  SettingsViewController.swift
//  BluetoothDemo
//
//  Created by CCX on 2020/7/24.
//  Copyright © 2020 sky. All rights reserved.
//

import UIKit

class SettingsViewController: UITableViewController {
    
    var dataArray = [MenuItem]();
    var timePicker : UIDatePicker?;
    var currentDevice:BTDeviceInfo?;
    var alertView : UIAlertController?;
    var mode: AHTempMode?;
    
    override func viewDidLoad() {
        super.viewDidLoad();
        //根据设备类型，初始化功能接口菜单
        if(self.currentDevice?.deviceType == BTDeviceType.oximeter){
            //血糖仪
            self.dataArray = self.initBomMenu();
        }
        else if(self.currentDevice?.deviceType == BTDeviceType.bloodPressureMeter){
            //血压计
            self.dataArray = self.initBpmMenu();
        }
        else{
            self.dataArray = self.initTempMenu();
        }
    }
    
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1;
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.dataArray.count;
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell: UITableViewCell? = tableView.dequeueReusableCell(withIdentifier: "settingCell");
        if(cell == nil){
            cell=UITableViewCell.init(style:UITableViewCell.CellStyle.subtitle , reuseIdentifier: "settingCell");
        }
        cell?.accessoryType = .disclosureIndicator;
        let item :MenuItem = self.dataArray[indexPath.row] ;
        cell?.textLabel?.text = item.title;
        return cell!;
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true);
        let item :MenuItem = self.dataArray[indexPath.row] ;
        //handle item action
        item.action!();
    }
    
    
    // MARK: - Private Methods
    
    ///血糖仪功能设置接口
    private func initBomMenu() -> [MenuItem]{
        var menus = [MenuItem]();
        menus.append(MenuItem.init(name: "Start Sync", funcName: {
            let setting = AHSpO2SyncSetting();
            setting.enable = true;
            self.pushSetting(setting: setting);
        }));
        menus.append(MenuItem.init(name: "Stop Sync", funcName: {
            let setting = AHSpO2SyncSetting();
            setting.enable = false;
            self.pushSetting(setting: setting);
        }));
        return menus;
    }
    
    ///温度计功能设置接口
    private func initTempMenu() -> [MenuItem]{
        var menus = [MenuItem]();
        menus.append(MenuItem.init(name: "Latest Data(0xD1)", funcName: {
            let setting = AHTempSetting.init(cmd: .syncLatestData);
            self.pushSetting(setting: setting!);
        }));
        menus.append(MenuItem.init(name: "Sync Data(0xD3)", funcName: {
            let setting = AHTempSetting.init(cmd: .syncData);
            self.pushSetting(setting: setting!);
        }));
        menus.append(MenuItem.init(name: "Remove Data(0xD4)", funcName: {
            let setting = AHTempSetting.init(cmd: .clearData);
            self.pushSetting(setting: setting!);
        }));
        menus.append(MenuItem.init(name: "Device Status(0xD5)", funcName: {
            let setting = AHTempSetting.init(cmd: .queryStatus);
            self.pushSetting(setting: setting!);
        }));
        menus.append(MenuItem.init(name: "Measurement Mode(0xD6)", funcName: {
            self.switchMode();
        }));
        
        menus.append(MenuItem.init(name: "Sync Data(0xD9)", funcName: {
            let setting = AHTempSetting.init(cmd: .newSyncData);
            self.pushSetting(setting: setting!);
        }));
        
        menus.append(MenuItem.init(name: "Sync Time(0xD8)", funcName: {
            let setting = AHTempSetting.init(cmd: .newSyncTime);
            self.pushSetting(setting: setting!);
        }));
        
        menus.append(MenuItem.init(name: "Start Measuring(0xDA)", funcName: {
            let setting = AHTempSetting.init(cmd: .startMeasuring);
            self.pushSetting(setting: setting!);
        }));
        
        menus.append(MenuItem.init(name: "Sync Time(0xD2)", funcName: {
            let setting = AHTempSetting.init(cmd: .syncTime);
            self.pushSetting(setting: setting!);
        }));
        menus.append(MenuItem.init(name: "Measurement Unit(0xD6)", funcName: {
            self.switchUnit();
        }));
        return menus;
    }
    
    ///血压计功能设置接口
    private func initBpmMenu() -> [MenuItem]{
        var menus = [MenuItem]();
        menus.append(MenuItem.init(name: "Start Measuring", funcName: {
            let setting = AHBpmConfigSetting.init();
            setting.config = .startMeasuring;
            self.pushSetting(setting: setting);
        }));
        menus.append(MenuItem.init(name: "Stop Measuring", funcName: {
            let setting = AHBpmConfigSetting.init();
            setting.config = .stopMeasuring;
            self.pushSetting(setting: setting);
        }));
        menus.append(MenuItem.init(name: "Sync Data", funcName: {
            self.syncBpmData();
        }));
        menus.append(MenuItem.init(name: "Remove Data", funcName: {
            self.removeBpmData();
        }));
        menus.append(MenuItem.init(name: "Switch User", funcName: {
            self.switchUser();
        }));
        menus.append(MenuItem.init(name: "Voice Control", funcName: {
            self.voiceControl();
        }));
        menus.append(MenuItem.init(name: "Device Status", funcName: {
            let setting = AHBpmConfigSetting.init();
            setting.config = .statusSync;
            self.pushSetting(setting: setting);
        }));
        menus.append(MenuItem.init(name: "Sync Time(0xD9)", funcName: {
            let setting = AHBpmConfigSetting.init();
            setting.config = .systemTime;
            self.pushSetting(setting: setting);
        }));
        menus.append(MenuItem.init(name: "Sync Time(0xB1)", funcName: {
            let setting = AHBpmConfigSetting.init();
            setting.config = .timeSync;
            self.pushSetting(setting: setting);
        }));
        menus.append(MenuItem.init(name: "Power Off", funcName: {
            let setting = AHBpmConfigSetting.init();
            setting.config = .powerOff;
            self.pushSetting(setting: setting);
        }));
        menus.append(MenuItem.init(name: "Get SN", funcName: {
            let setting = AHBpmConfigSetting.init();
            setting.config = .getSn;
            self.pushSetting(setting: setting);
        }));
        menus.append(MenuItem.init(name: "Online Check", funcName: {
            let setting = AHBpmConfigSetting.init();
            setting.config = .onlineCheck;
            self.pushSetting(setting: setting);
        }));
        menus.append(MenuItem.init(name: "Cancel Voice Prompt", funcName: {
            let setting = AHBpmConfigSetting.init();
            setting.config = .cancelVoicePrompt;
            self.pushSetting(setting: setting);
        }));
        return menus;
    }
    
    /**
     * 返回上级视图，并设置表盘文件路径
     */
    func popViewController(url:URL) {
        let viewControllers: [UIViewController] = self.navigationController!.viewControllers
        for aViewController in viewControllers {
            if aViewController is ConnectViewController {
                let myVC = aViewController as! ConnectViewController;
                myVC.wfFilePath = url ;
                self.navigationController!.popToViewController(aViewController, animated: true);
                return;
            }
        }
    }
    
    private func showOptionsSetting(item : [SettingItem],title : String){
        AlertUtils.showSelectView(title: title, selectDelegate: self, dataSource: item, controler: self);
    }
    
    private func pushSetting(setting:BTDeviceSetting){
        self.alertView = AlertUtils.showLoadingView(title:  Constants.Setting.keySyncing, msg:" \n\n", cancelBtn: false);
        self.present(self.alertView!, animated: true) {
            AHDevicePlugin.default()?.push(setting, toDevice: self.currentDevice!, response: { (state, error, data) in
                var msg = String.init(format: Constants.Setting.keySyncFailed, error);
                if(state){
                    msg = Constants.Setting.keySyncSuccess;}
                print("\(msg),resp=\(data ?? "no data")");
                DispatchQueue.main.async {
                    self.alertView?.title = msg;
                    Timer.scheduledTimer(timeInterval: 1, target: self,
                    selector: #selector(self.dismissToastView(timer:)), userInfo: nil, repeats: false)
                };
            });
        }
    }
    
    @objc private func dismissToastView(timer: Timer) {
        self.dismiss(animated: true, completion:nil);
    }
    
    private func showAlertView(title:String?,msg:String?){
        let alert : UIAlertController = AlertUtils.showPrompt(title: title, msg: msg, cancelBtn: false);
        self.present(alert, animated: true, completion: nil);
    }
}


//MARK: SettingItemDelegate

extension SettingsViewController : SettingItemDelegate
{
    func didSelectRowAtItem(item: SettingItem) {
        self.dismiss(animated: true, completion: nil);
        if(item.action != nil){
            //trigger item's action
            item.action!(item,item.index);
        }
        else{
            print("item select \(item.title),index=\(item.index)");
        }
    }
    
    
    
    //MARK: Setting

    /**
     * AHSpO2AlarmSetting
     */
    private func alarmSetting() ->Void{
        let setting : AHSpO2AlarmSetting = AHSpO2AlarmSetting();
        let alarm : AHSpO2Alarm = AHSpO2Alarm();
        setting.option = 1;
        setting.alarm = alarm;
        
        var options = [SettingItem]();
        options.append(SettingItem.init(title: Constants.Setting.keyMaxSpO2, type: .Number, index: 0x00, subTitle: nil, funcName: {(item,value) in
            if(value != nil ){
                alarm.maxSpo2 = Int32(UInt.init(value as! String)!);
            }
        }));
        options.append(SettingItem.init(title: Constants.Setting.keyMinSpO2, type: .Number, index: 0x00, subTitle: nil, funcName: {(item,value) in
            if(value != nil ){
                alarm.minSpo2 = Int32(UInt.init(value as! String)!);
            }
        }));
        options.append(SettingItem.init(title: Constants.Setting.keyMaxPulseRate, type: .Number, index: 0x00, subTitle: nil, funcName: {(item,value) in
            if(value != nil ){
                alarm.maxPulseRate = Int32(UInt.init(value as! String)!);
            }
        }));
        options.append(SettingItem.init(title: Constants.Setting.keyMinPulseRate, type: .Number, index: 0x00, subTitle: nil, funcName: {(item,value) in
            if(value != nil ){
                alarm.minPulseRate = Int32(UInt.init(value as! String)!);
            }
        }));
        AlertUtils.showSettingView(title: Constants.SettingItem.keySpO2Alarm, selectDelegate: self, dataSource: options, controler: self,handler: {(action) in
            //push to device
            self.pushSetting(setting: setting);
        });
    }
    
    
    /**
     * 测温模式切换
     */
    private func switchMode() -> Void{
        var options = [SettingItem]();
        Constants.TempMeasurementMode.allCases.forEach { (str) in
            let title = String.init(format: "%@", str.rawValue);
            let cmd = AuxiliaryUtils.formatTempModeItem(item: str);
            let item = SettingItem.init(title: title, type: .QueryCmd, index: 0x00, subTitle: nil) {(item,value) in
                let setting : AHTempSetting = AHTempSetting(cmd: AHTempCmd.configMode);
                setting.mode = cmd;
                self.pushSetting(setting: setting);
            }
            options.append(item);
        }
        self.showOptionsSetting(item: options, title: "Switch Mode");
    }
    
    /**
     * 测温模式切换
     */
    private func switchUnit() -> Void{
        var options = [SettingItem]();
        Constants.TempMeasurementUnit.allCases.forEach { (str) in
            let title = String.init(format: "%@", str.rawValue);
            let num = Constants.TempMeasurementUnit.allCases.firstIndex(of: str);
            let item = SettingItem.init(title: title, type: .QueryCmd, index: num!, subTitle: nil) {(item,value) in
                let setting : AHTempSetting = AHTempSetting(cmd: AHTempCmd.configMode);
                setting.mode = self.mode ?? .adult;
                setting.unit = Int32(item.index);
                self.pushSetting(setting: setting);
            }
            options.append(item);
        }
        self.showOptionsSetting(item: options, title: "Switch Unit");
    }
    
    
    
    /**
     *  血压计测量数据同步
     */
    private func syncBpmData() -> Void{
        var options = [SettingItem]();
        Constants.UserData.allCases.forEach { (str) in
            let title = String.init(format: "%@", str.rawValue);
            let num = Constants.UserData.allCases.firstIndex(of: str);
            let item = SettingItem.init(title: title, type: .QueryCmd, index:num!, subTitle: nil) {(item,value) in
                let setting : AHBpmSyncSetting = AHBpmSyncSetting();
                if(item.index == 0){
                    setting.syncAll = true;
                }
                else{
                    setting.userNum = Int32(item.index);
                }
                print("item select \(item.title),index=\(item.index)");
                self.pushSetting(setting: setting);
            }
            options.append(item);
        }
        self.showOptionsSetting(item: options, title: "Sync User Data");
    }
    
    /**
     *  血压计测量数据删除
     */
    private func removeBpmData() -> Void{
        var options = [SettingItem]();
        Constants.UserData.allCases.forEach { (str) in
            let title = String.init(format: "%@", str.rawValue);
            let num = Constants.UserData.allCases.firstIndex(of: str);
            let item = SettingItem.init(title: title, type: .QueryCmd, index:num!, subTitle: nil) {(item,value) in
                let setting : AHBpmRemoveSetting = AHBpmRemoveSetting();
                if(item.index == 0){
                    setting.removeAll = true;
                }
                else{
                    setting.userNum = Int32(item.index);
                }
                self.pushSetting(setting: setting);
            }
            options.append(item);
        }
        self.showOptionsSetting(item: options, title: "Remove User Data");
    }
    
    /**
     *  血压计测量用户切换
     */
    private func switchUser() -> Void{
        var options = [SettingItem]();
        Constants.DeviceUsers.allCases.forEach { (str) in
            let title = String.init(format: "%@", str.rawValue);
            let num = Constants.DeviceUsers.allCases.firstIndex(of: str);
            let item = SettingItem.init(title: title, type: .QueryCmd, index:num!, subTitle: nil) {(item,value) in
                let setting : AHBpmConfigSetting = AHBpmConfigSetting();
                setting.config = AHBpmConfig.switchUser;
                setting.user = Int32(item.index + 1);
                self.pushSetting(setting: setting);
            }
            options.append(item);
        }
        self.showOptionsSetting(item: options, title: "Switch User");
    }
    
    /**
     * 语音控制
     */
    private func voiceControl() -> Void{
        let setting:AHBpmConfigSetting = AHBpmConfigSetting();
        setting.config = .voiceControl;
        setting.voiceState = true;
        var options = [SettingItem]();
        options.append(SettingItem.init(title: "Voice Control State", type: .Switch, index: 0x00, subTitle: nil, funcName: {(item,value) in
            if(value != nil ){
                setting.voiceState = value as! Bool;
            }
            print("item select \(item.title),index=\(setting.voiceState)");

        }));
        
        AlertUtils.showSettingView(title: "Voice Control", selectDelegate: self, dataSource: options, controler: self,handler: {(action) in
            //push to device
            self.pushSetting(setting: setting);
        });
    }
    
}



