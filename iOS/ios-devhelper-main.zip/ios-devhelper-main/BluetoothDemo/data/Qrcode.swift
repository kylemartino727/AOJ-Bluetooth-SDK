//
//  QrcodeData.swift
//  BluetoothDemo
//
//  Created by CCX on 2020/7/21.
//  Copyright © 2020 sky. All rights reserved.
//

import Foundation


class QrCode{
    
    //MARK: Properties
    
    var str:String;
    var mac: String;
    var code: String;
    
    // var str="MAC:DA32CAEEB8F0 CODE:123456";
    init?(content: String?) {
        self.str="";
        self.mac="";
        self.code="";
        if(content == nil){
            return;
        }
        print("qr code = \(content ?? "no data")");
        if(content?.range(of: ":") != nil){
            let arraySubstrings: [Substring] = content!.split(separator: " ");
            //to string
            let _: [String] = arraySubstrings.compactMap {
                (item) -> String in
                let itemStr = "\(item)";
                if(itemStr.contains("MAC") || itemStr.contains("mac")){
                    //parse mac
                    self.mac="\(itemStr.split(separator: ":")[1])";
                }
                if(itemStr.contains("CODE") || itemStr.contains("code")){
                    //parse code
                    self.code="\(itemStr.split(separator: ":")[1])";
                }
                return itemStr;
            }
        }
        else if(content?.range(of: "-") != nil){
            let arraySubstrings: [Substring] = content!.split(separator: "-");
            arraySubstrings.compactMap {
                (item) -> Void in
                let itemStr = "\(item)";
                print("item of code value \(item)");
                if(itemStr.count == 12){
                    self.mac = itemStr;
                }
                else if(itemStr.count == 6){
                    self.code = itemStr;
                }
            }
        }

    }
}
