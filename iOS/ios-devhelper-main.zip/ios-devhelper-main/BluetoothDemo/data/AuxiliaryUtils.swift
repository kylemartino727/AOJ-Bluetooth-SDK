//
//  AuxiliaryUtils.swift
//  BluetoothDemo
//
//  Created by CCX on 2020/7/30.
//  Copyright © 2020 sky. All rights reserved.
//

import Foundation


struct AuxiliaryUtils{
    @available(*,unavailable)
    private init(){}
    

    static func formatTempModeItem(item : Constants.TempMeasurementMode) -> AHTempMode{
        var value = AHTempMode.unknown;
        Constants.TempMeasurementMode.allCases.forEach{(str) in
            switch(item){
            case .adult: value = .adult
            case .children: value = .children
            case .ear: value = .ear
            case .material: value = .material
            }
        }
        return value;
    }
    
}
