//
//  SettingItem.swift
//  BluetoothDemo
//
//  Created by CCX on 2020/7/23.
//  Copyright © 2020 sky. All rights reserved.
//

import Foundation

enum ItemType:Int{
    case Number = 0x00
    case TimePicker = 0x01
    case TimeSecondPicker = 0x02
    case SingleChoice = 0x03
    case MultipleChoice = 0x04
    case Text = 0x05
    case Image = 0x06
    case File = 0x07
    case QueryCmd = 0x08
    case Switch = 0x09
    case Title = 0x10
    case NumbersAndPunctuation = 0x11
    case Dial = 0x12
    case SwithIndex = 0x13
    
    case SyncFile = 0x14
    case PushFile = 0x15
    case Share = 0x16
}

class SettingItem {
    
    var title : String = "";
    var subTitle : String = "";
    var type : ItemType = .Text;
    var index : Int = 0;
    var filePath : String?;
    var action : ((_ self : SettingItem,_ data:Any?)->Void)? ;
    var choiceItems = [String]();

    init(title : String, type : ItemType,index: Int, subTitle:String?,funcName:((_ self : SettingItem,_ data:Any?)->Void)?) {
        self.title = title;
        self.type = type;
        self.index = index;
        self.subTitle = subTitle ?? "";
        self.action = funcName;
    }
    
    
}
