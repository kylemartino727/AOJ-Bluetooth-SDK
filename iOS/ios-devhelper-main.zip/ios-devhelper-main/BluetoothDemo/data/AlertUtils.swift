//
//  AlertUtils.swift
//  BluetoothDemo
//
//  Created by CCX on 2020/7/9.
//  Copyright © 2020 sky. All rights reserved.
//

import Foundation
import UIKit

struct AlertUtils{
    @available(*,unavailable)
    private init(){}
    
    
    static func showTimePicker(title:String,view:UIViewController,handler:((UIAlertAction) -> Void)? = nil) -> UIDatePicker
    {
        let alert:UIAlertController=UIAlertController.init(title: title, message: nil, preferredStyle: UIAlertController.Style.alert);
        let pickerView = UIDatePicker();
        pickerView.datePickerMode = .countDownTimer;
        pickerView.date = Date.init();
        //UIViewController
        let contentView:UIViewController=UIViewController.init();
        contentView.preferredContentSize=CGRect.init(x: 0, y: 0, width: 272, height: 200).size;
        contentView.view.addSubview(pickerView);
        contentView.view.bringSubviewToFront(pickerView);
        contentView.view.isUserInteractionEnabled=true;
        //reset UIAlertController View
        alert.setValue(contentView, forKey: "contentViewController");
        alert.addAction(UIAlertAction.init(title: "OK", style: .default, handler: handler));
        view.present(alert, animated: true, completion: nil);
        return pickerView;
    }
    
    
    /**
     * ActionSheet Of ViewController
     */
    static func showActionSheet(menus:[MenuItem], title:String, view:UIViewController)
    {
        let alert:UIAlertController=UIAlertController.init(title: title, message: nil, preferredStyle: UIAlertController.Style.actionSheet);
        alert.addAction(UIAlertAction.init(title: "Cancel", style: .cancel, handler: nil));
        for menuItem in menus {
            alert.addAction(UIAlertAction.init(title: menuItem.title, style: .default, handler: { (action) in
                view.dismiss(animated: true, completion: nil);
                menuItem.action!();
            }))
        }
        //        alert.popoverPresentationController?.sourceRect = CGRect.init(x: 0, y: 200, width: 768, height: 20);//( 0,200,768,20);
        alert.view.addSubview(UIView());
        view.present(alert, animated: true, completion: nil);
        // Present之后添加代码如下
        alert.view.subviews.flatMap({$0.constraints}).filter{ (one: NSLayoutConstraint)-> (Bool)  in
            return (one.constant < 0) && (one.secondItem == nil) &&  (one.firstAttribute == .width)
        }.first?.isActive = false
    }
    
    /**
     * InputView Of ViewController
     */
    static func showInputView(msg:String?,cancelBtn:Bool,handler:((UIAlertAction) -> Void)? = nil) -> UIAlertController{
        let alert:UIAlertController=UIAlertController.init(title: nil, message: msg, preferredStyle: UIAlertController.Style.alert);
        alert.addTextField { (textField) in
            //textField.placeholder = ;
            textField.textColor = UIColor.blue;
            textField.clearButtonMode = .whileEditing ;
            textField.borderStyle = .roundedRect;
        }
        let okAction:UIAlertAction=UIAlertAction.init(title: "OK", style: UIAlertAction.Style.default, handler: handler);
        alert.addAction(okAction);
        if(cancelBtn){
            let cancel:UIAlertAction=UIAlertAction.init(title: "Cancel", style: UIAlertAction.Style.destructive, handler: nil);
            alert.addAction(cancel);
        }
        return alert;
    }
    
    /**
     * View Of UIAlertController
     */
    static func showPrompt(title:String?,msg:String?,cancelBtn:Bool,handler:((UIAlertAction) -> Void)? = nil) -> UIAlertController{
        let alert:UIAlertController=UIAlertController.init(title: title, message: msg, preferredStyle: UIAlertController.Style.alert);
        let okAction:UIAlertAction=UIAlertAction.init(title: "OK", style: UIAlertAction.Style.default, handler: handler);
        alert.addAction(okAction);
        if(cancelBtn){
            let cancel:UIAlertAction=UIAlertAction.init(title: "Cancel", style: UIAlertAction.Style.destructive, handler: nil);
            alert.addAction(cancel);
        }
        return alert;
    }
    
    /**
     * Add UIActivityIndicatorView IN UIAlertController
     */
    static func showLoadingView(title:String?,msg:String?,cancelBtn:Bool,handler:((UIAlertAction) -> Void)? = nil) -> UIAlertController{
        let alert:UIAlertController=UIAlertController.init(title: title, message: msg, preferredStyle: UIAlertController.Style.alert);
        //add action
        if(cancelBtn){
            let cancelAction:UIAlertAction=UIAlertAction.init(title: "Cancel", style: UIAlertAction.Style.destructive, handler: handler);
            alert.addAction(cancelAction);
        }
        //Activity Indicator View
        let indicatorView:UIActivityIndicatorView=UIActivityIndicatorView.init(style: UIActivityIndicatorView.Style.whiteLarge);
        indicatorView.color=UIColor.brown;
        indicatorView.translatesAutoresizingMaskIntoConstraints=false;
        indicatorView.isUserInteractionEnabled=false;
        indicatorView.startAnimating();
        //add view
        alert.view.addSubview(indicatorView);
        //add constraints
        alert.view.addConstraints([NSLayoutConstraint.init(item: indicatorView, attribute: NSLayoutConstraint.Attribute.centerX, relatedBy: NSLayoutConstraint.Relation.equal, toItem: alert.view, attribute: NSLayoutConstraint.Attribute.centerX, multiplier: 1.0, constant: 0.0)]);
        
        alert.view.addConstraints([NSLayoutConstraint.init(item: indicatorView, attribute: NSLayoutConstraint.Attribute.centerY, relatedBy: NSLayoutConstraint.Relation.equal, toItem: alert.view, attribute: NSLayoutConstraint.Attribute.centerY, multiplier: 1.0, constant: 0.0)]);
        return alert;
    }
    
    /**
     * Add UITableView IN UIAlertController
     */
    static func showTableAlertView(title:String?,selectDelegate:SettingItemDelegate?, dataSource:[Any]?,handler:((UIAlertAction) -> Void)? = nil) -> UIAlertController{
        let alert:UIAlertController=UIAlertController.init(title: title, message: nil, preferredStyle: UIAlertController.Style.alert);
        //add action
        let cancelAction:UIAlertAction=UIAlertAction.init(title: "Cancel", style: UIAlertAction.Style.destructive, handler: handler);
        alert.addAction(cancelAction);
        //UITableView
        let table:CustomTableView = CustomTableView.init(frame: CGRect.init(x: 0, y: 0, width: 272, height: 300));
        table.dataArray=dataSource as! [SettingItem];
        table.itemSelectDelegate=selectDelegate;
        //UIViewController
        let contentView:UIViewController=UIViewController.init();
        contentView.preferredContentSize=CGRect.init(x: 0, y: 0, width: 272, height: 300).size;
        contentView.view.addSubview(table);
        contentView.view.bringSubviewToFront(table);
        contentView.view.isUserInteractionEnabled=true;
        //reset UIAlertController View
        alert.setValue(contentView, forKey: "contentViewController");
        return alert;
    }
    
    /**
     * Add UITableView IN UIAlertController
     */
    static func showSelectView(title:String?,selectDelegate:SettingItemDelegate?, dataSource:[Any]?, controler:UIViewController,handler:((UIAlertAction) -> Void)? = nil){
        let alert:UIAlertController=UIAlertController.init(title: title, message: nil, preferredStyle: UIAlertController.Style.alert);
        //add action
        let cancelAction:UIAlertAction=UIAlertAction.init(title: "Cancel", style: UIAlertAction.Style.cancel, handler: handler);
        alert.addAction(cancelAction);
        //UITableView
        let table:CustomTableView = CustomTableView.init(frame: CGRect.init(x: 0, y: 0, width: 272, height: 300));
        table.dataArray=dataSource as! [SettingItem];
        table.itemSelectDelegate=selectDelegate;
        //UIViewController
        let contentView:UIViewController=UIViewController.init();
        contentView.preferredContentSize=CGRect.init(x: 0, y: 0, width: 272, height: 300).size;
        contentView.view.addSubview(table);
        contentView.view.bringSubviewToFront(table);
        contentView.view.isUserInteractionEnabled=true;
        //reset UIAlertController View
        alert.setValue(contentView, forKey: "contentViewController");
        
        controler.present(alert, animated: true, completion: nil);
    }
    
    /**
     * Add UITableView IN UIAlertController
     */
    static func showSettingView(title:String?,selectDelegate:SettingItemDelegate?, dataSource:[Any]?, controler:UIViewController,handler:((UIAlertAction) -> Void)? = nil){
        let alert:UIAlertController=UIAlertController.init(title: title, message: nil, preferredStyle: UIAlertController.Style.alert);
        //add action
        let cancelAction:UIAlertAction=UIAlertAction.init(title: "Cancel", style: UIAlertAction.Style.destructive, handler: nil);
        alert.addAction(cancelAction);
        
        let okAction:UIAlertAction=UIAlertAction.init(title: "OK", style: UIAlertAction.Style.default, handler: handler);
        alert.addAction(okAction);
        //UITableView
        let table:SettingTableView = SettingTableView.init(frame: CGRect.init(x: 0, y: 0, width: 272, height: 300));
        table.dataArray=dataSource as! [SettingItem];
        table.itemSelectDelegate=selectDelegate;
        //UIViewController
        let contentView:UIViewController=UIViewController.init();
        contentView.preferredContentSize=CGRect.init(x: 0, y: 0, width: 272, height: 300).size;
        contentView.view.addSubview(table);
        contentView.view.bringSubviewToFront(table);
        contentView.view.isUserInteractionEnabled=true;
        //reset UIAlertController View
        alert.setValue(contentView, forKey: "contentViewController");
        alert.presentingViewController?.preferredContentSize
        
        controler.present(alert, animated: true, completion: nil);
    }
}
