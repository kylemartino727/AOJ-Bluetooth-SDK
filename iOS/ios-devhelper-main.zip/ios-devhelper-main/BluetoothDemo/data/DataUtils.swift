//
//  ByteUtils.swift
//  BluetoothDemo
//
//  Created by CCX on 2020/7/13.
//  Copyright © 2020 sky. All rights reserved.
//

import Foundation


extension Data{
    var hexadecimal: String {
        return map { String(format: "%02X", $0) }.joined();
    }
}
