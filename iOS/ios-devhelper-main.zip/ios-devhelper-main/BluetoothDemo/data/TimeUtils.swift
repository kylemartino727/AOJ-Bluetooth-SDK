//
//  TimeUtils.swift
//  BluetoothDemo
//
//  Created by CCX on 2020/7/30.
//  Copyright © 2020 sky. All rights reserved.
//

import Foundation

struct TimeUtils{
    @available(*,unavailable)
    private init(){}
    
    static let dateformatter = DateFormatter();

    static func currentTime() -> String {
        let nowDate = Date.init();
        self.dateformatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        //自定义日期格式
        return "\(dateformatter.string(from: nowDate))";
    }
    
    static func hourAndMinute(date : Date) -> String{
        self.dateformatter.dateFormat = "HH:mm"
         return "\(dateformatter.string(from: date))";
    }
    
    static func currentUtc() -> Int32 {
        let nowDate = Date.init();
        return Int32.init(nowDate.timeIntervalSince1970);
    }
    
    static func countUpdateTime(startTime:TimeInterval) -> String{
        if(startTime == 0){
            return "#";
        }
        let endTime : TimeInterval = Date.init().timeIntervalSince1970;
        
        let interval = Int(endTime - startTime);
        let seconds = interval % 60 ;
        let minutes = (interval / 60) % 60 ;
        let hours = (interval / 3600);
        if(hours > 0){
            return String(format: "Time= %02d h:%02d m:%02d s", hours, minutes, seconds)
        }
        else if(minutes > 0 ){
            return String(format: "Time= %02d m:%02d s", minutes, seconds)
        }
        else {
            return String(format: "Time= %02d h:%02d m:%02d s", hours, minutes, seconds)
        }
    }
    
}
