//
//  Constants.swift
//  BluetoothDemo
//
//  Created by CCX on 2020/7/9.
//  Copyright © 2020 sky. All rights reserved.
//

import Foundation

struct Constants {
    struct CoreData {
        static let modelName="PairedDevice";
    }
    
    struct PairedDevice {
        static let keyName="name";
        static let keyDeviceId="deviceId";
        static let keyDeviceSn="deviceSn";
        static let keyBroadcastId="broadcastId";
        static let keyMacAddress="macAddress";
        static let keyDeviceType="deviceType";
        static let keyProtocolType="protocolType";
        static let keyManufacturerData="manufacturerData";
        static let keyUserNumber="userNumber";
    }
    
    struct Search {
        static let bluetoothUnavailable=NSLocalizedString("bluetoothUnavailable", comment: "");
        static let scanning=NSLocalizedString("scanning",comment: "");
        static let scanResults=NSLocalizedString("scanResults",comment: "");
        static let notDeviceFound=NSLocalizedString("notDeviceFound",comment: "");
        static let randomCodeInput=NSLocalizedString("randomCodeInput",comment: "");
    }
    
    struct Pairing {
        static let title = NSLocalizedString("pairingTitle",comment: "");//"pairing...\n\n";
        static let stateFailure=NSLocalizedString("stateFailure",comment: "");//"Pairing failed.";
        static let stateSuccess=NSLocalizedString("stateSuccess",comment: "");
        static let pairWithRandomNum=NSLocalizedString("pairWithRandomNum",comment: "");
        static let pairWithAuto=NSLocalizedString("pairWithAuto",comment: "");
        static let pairIgnore=NSLocalizedString("pairIgnore",comment: "");
        static let pairModeTitle=NSLocalizedString("pairModeTitle",comment: "");

    }
    
    struct FileUpdate {
        static let keyFirmwareUpdate = NSLocalizedString("keyFirmwareUpdate",comment: "");
        static let keyDialUpdate = NSLocalizedString("keyDialUpdate",comment: "");
        static let notFileFound=NSLocalizedString("notFileFound",comment: "");
        static let fileSelect=NSLocalizedString("fileSelect",comment: "");
        static let notConnect=NSLocalizedString("notConnect",comment: "");
        static let keyUpdateFailed=NSLocalizedString("keyUpdateFailed",comment: "");
        static let keyUpdateSuccess=NSLocalizedString("keyUpdateSuccess",comment: "");
    }
    
    struct Connect{
        static let keyConnecting=NSLocalizedString("keyConnecting",comment: "");
        static let keyConnected=NSLocalizedString("keyConnected",comment: "");
        static let keyDisconnect=NSLocalizedString("keyDisconnect",comment: "");
        static let keyUnbind = NSLocalizedString("keyUnbind",comment: "");
        static let keyNotConnected = NSLocalizedString("keyNotConnected",comment: "");
    }
    
    struct Menu {
        static let keyTitle=NSLocalizedString("keyTitle",comment: "");
        static let keyConnect=NSLocalizedString("keyConnect",comment: "");
        static let keyDisconnect=NSLocalizedString("keyDisconnect",comment: "");
        static let keySetting=NSLocalizedString("keySetting",comment: "");
        static let keyReadBattery=NSLocalizedString("keyReadBattery",comment: "");
        static let keyQueryData=NSLocalizedString("keyQueryData",comment: "");
        static let keyDeviceUnbind=NSLocalizedString("keyDeviceUnbind",comment: "");
        static let keyDial=NSLocalizedString("keyDial",comment: "");
        static let keyShareLog = NSLocalizedString("keyShare",comment: "");
        static let keyDataType=NSLocalizedString("keyDataType",comment: "");
        static let keyGpsState=NSLocalizedString("keyGpsState",comment: "");
        static let keyUpdateType=NSLocalizedString("keyUpdateType",comment: "");
        static let keyClearLog = NSLocalizedString("keyClearlog",comment: "");

    }
    
    struct SettingItem {
        static let keyAlarmClock=NSLocalizedString("keyAlarmClock",comment: "");
        static let keyHeartRateDetect=NSLocalizedString("keyHeartRateDetect",comment: "");
        static let keyHeartRateAlert=NSLocalizedString("keyHeartRateAlert",comment: "");
        static let keyHeartRateRange=NSLocalizedString("keyHeartRateRange",comment: "");
        static let keyTimeFormat=NSLocalizedString("keyTimeFormat",comment: "");
        static let keyDistanceFormat=NSLocalizedString("keyDistanceFormat",comment: "");
        static let keyDialStyle=NSLocalizedString("keyDialStyle",comment: "");
        static let keySendary=NSLocalizedString("keySendary",comment: "");
        static let keyWeather=NSLocalizedString("keyWeather",comment: "");
        static let keyStepGoal=NSLocalizedString("keyStepGoal",comment: "");
        static let keyFunPages=NSLocalizedString("keyFunPages",comment: "");
        static let keySpeed=NSLocalizedString("keySpeed",comment: "");
        static let keyMusic=NSLocalizedString("keyMusic",comment: "");
        static let keyBacklight=NSLocalizedString("keyBacklight",comment: "");
        static let keyDrinkWater=NSLocalizedString("keyDrinkWater",comment: "");
        static let keyTakePictures=NSLocalizedString("keyTakePictures",comment: "");
        static let keyLanguage=NSLocalizedString("keyLanguage",comment: "");
        static let keyUnit=NSLocalizedString("keyUnit",comment: "");
        static let keyDialFile=NSLocalizedString("keyDialFile",comment: "");
        static let keyUserInfo=NSLocalizedString("keyUserInfo",comment: "");
        
        static let keyNightMode=NSLocalizedString("keyNightMode",comment: "");
        static let keyScreenMode=NSLocalizedString("keyScreenMode",comment: "");
        static let keyWearingStyle=NSLocalizedString("keyWearingStyle",comment: "");
        static let keyExerciseMode=NSLocalizedString("keyExerciseMode",comment: "");
        static let keyScreenPowerOn=NSLocalizedString("keyScreenPowerOn",comment: "");
        
        
        static let keyIotDevice=NSLocalizedString("keyIotDevice",comment: "");
        
        static let keyDevicePosition = NSLocalizedString("keyDevicePosition",comment: "");//"iOT控制"
        static let keyShareLog = NSLocalizedString("keyShareLog",comment: "");//"iOT控制"

        static let keyMoodClock=NSLocalizedString("keyMoodClock",comment: "");
        static let keyMoodName=NSLocalizedString("keyMoodName",comment: "");
        
        //AOJ
        static let keySpO2Alarm=NSLocalizedString("keySpO2Alarm",comment: "");

    }

    enum QueryCmd : String , CaseIterable {
        case All = "All(0xFF)"
        case BuriedPoint = "BuriedPoint(0xF0)"
        case BuriedPointSummary = "BuriedPointSummary(0xF1)"
    }
    
    struct Setting {
        static let keySyncing = NSLocalizedString("keySyncing",comment: "");//"syncing... "
        static let keySyncSuccess = NSLocalizedString("keySyncSuccess",comment: "");//"Setting success"
        static let keySyncFailed = NSLocalizedString("keySyncFailed",comment: "");//"Setting failed,error = %d"

        static let titleFailed = NSLocalizedString("titleFailed",comment: "");//"Setting failed,error = %d"
        static let titleSuccess = NSLocalizedString("titleSuccess",comment: "");//"Setting success"
        static let titleTime = NSLocalizedString("titleTime",comment: "");//"格式 HH:MM"
        static let titleWeatherType = NSLocalizedString("titleWeatherType",comment: "");//"范围 0x01~0x22"
        //static let keyTargetStep = "目标步数"
        static let keyState = NSLocalizedString("keyState",comment: "");//"提醒开关"
        static let keyStartTime = NSLocalizedString("keyStartTime",comment: "");//"开始时间"
        static let keyEndTime = NSLocalizedString("keyEndTime",comment: "");//"结束时间"
        static let keyVibrationTime = NSLocalizedString("keyVibrationTime",comment: "");//"振动时间"
        static let keyRemindCycle = NSLocalizedString("keyRemindCycle",comment: "");// "提醒周期"
        static let unitOfTime = NSLocalizedString("unitOfTime",comment: "");//"单位:Min"
        static let unitOfWeight = NSLocalizedString("unitOfWeight",comment: "");//"单位:kg"
        static let unitOfHeight = NSLocalizedString("unitOfHeight",comment: "");//"单位:M"
        static let keyRefresh = NSLocalizedString("keyRefresh",comment: "");//"刷新状态"
        static let keyLanguage = NSLocalizedString("keyLanguage",comment: "");//"语言"
        static let keyTempUnit = NSLocalizedString("keyTempUnit",comment: "");//"温度单位"
        static let keyBrightness = NSLocalizedString("keyBrightness",comment: "");//"显示亮度"
        static let keyUnit = NSLocalizedString("keyUnit",comment: "");//"单位"
        static let keyWatchFaceIndex = NSLocalizedString("keyWatchFaceIndex",comment: "");// "表盘索引"
        
        static let keyClockTime = NSLocalizedString("keyClockTime",comment: "");//"闹钟时间"
        static let keyClockTitle = NSLocalizedString("keyClockTitle",comment: "");//"闹钟标题"
        static let keyNapRemindTime = NSLocalizedString("keyNapRemindTime",comment: "");//"小睡提醒时间"
        static let keyWakeupTime = NSLocalizedString("keyWakeupTime",comment: "");//"浅睡提醒时间"
        
        static let keyRunStride = NSLocalizedString("keyRunStride",comment: "");//"跑步步长"
        static let keyWalkStride = NSLocalizedString("keyWalkStride",comment: "");//"走路步长"
        
        static let keyHeartRateMax = NSLocalizedString("keyHeartRateMax",comment: "");//"最大心率"
        static let keyHeartRateMin = NSLocalizedString("keyHeartRateMin",comment: "");//"最小心率"
        static let keyHeartRateFactor = NSLocalizedString("keyHeartRateFactor",comment: "");//"心率检测因子"
        static let keyHeartRateType = NSLocalizedString("keyHeartRateType",comment: "");//"心率类型"
        
        static let keyTargetStep = NSLocalizedString("keyTargetStep",comment: "");// "提醒目标"
        static let keyTargetType = NSLocalizedString("keyTargetType",comment: "");//"目标类型"
        static let keyTargetDistance = NSLocalizedString("keyTargetDistance",comment: "");//"距离目标"
        static let keyTargetCalories = NSLocalizedString("keyTargetCalories",comment: "");// "卡路里目标"
        static let keyDevName = NSLocalizedString("keyDevName",comment: "");// "卡路里目标"
        
        static let keyMaxSpO2 = NSLocalizedString("keyMaxSpO2",comment: "");
        static let keyMinSpO2 = NSLocalizedString("keyMinSpO2",comment: "");
        static let keyMaxPulseRate = NSLocalizedString("keyMaxPulseRate",comment: "");
        static let keyMinPulseRate = NSLocalizedString("keyMinPulseRate",comment: "");


    }
    
    enum HRDetectCycle : UInt , CaseIterable  {
        case Minutes5 = 5
        case Minutes10 = 10
        case Minutes15 = 15
        case Minutes30 = 30
    }
    
    enum TimeFormat : String , CaseIterable {
        case hour12 = "12 hr"
        case hour24 = "24 hr"
    }
    
    enum DistanceFormat : String , CaseIterable {
        case Mile = "Mile"
        case Km = "Km"
    }
    
    struct HeartRateAlert {
        static let keyMinHR = "Min Heart Rate"
        static let keyMaxHR = "Max Heart Rate"
    }
    
    struct UserInfo {
        static let keyAge = "Age"
        static let keyGender = "Gender"
        static let keyWeight = "Weight"
        static let keyHeight = "Height"
    }
    struct Sedentary {

        static let keySedentaryTime = "Sedentary Time"
    }
    
    struct Weather {
        static let keyType = "Weather Type"
        static let keyMinTemp = "Lowest Temperature"
        static let keyMaxTemp = "Maximum Temperature"
        static let keyAqi = "AQI"
        
        static let keyWindSpeed = "Wind Speed"
        static let keyRH = "Relative Humidity"
        static let keyUV = "UV"

    }
    
    struct ExerciseInfo {
        static let keySpeed = "Speed"
        static let keyDistance = "Distance"
    }
    
    struct Backlight {
        static let keyDayValue = "Daytime"
        static let keyNightValue = "Night"
    }

    struct DialInfo {
        static let keyIndex = "Index"
        static let keyId = "Id"
        static let keyType = "Type"
        static let keyName = "Name"
        static let keyBackgroudName = "Background Name"
        static let keyStyle = "Style"
    }
    
    struct MusicInfo {
        static let keyState = "Play State"
        static let keyVolume = "Volume"
        static let keySongTime = "Song Time"
        static let keyPlayTime = "Play Time"
        static let keySongName = "Song Name"
        static let keySinger = "Singer"
        static let keyAlbum = "Album"
        static let keyMaxVolume = "Max Volume"
    }
    
    enum GpsState : String,CaseIterable {
        case Unavailable = "GPS Unavailable"
        case Failure = "Positioning failed"
        case Success = "Positioning success"
        case Refuse = "Refuse"
    }
    
      
      enum ConfigQueryItem : String , CaseIterable  {
          case Flash = "Flash"
          case UserInfo = "UserInfo"
          case IncomingCallRemind = "IncomingCallRemind"
          case SedentaryRemind = "SedentaryRemind"
          case Stride = "Stride"
          case VibrationIntensity = "VibrationIntensity"
          case DisplayBrightness = "Brightness"
          case AlarmClock = "AlarmClock"
          case Settings = "Settings"
      }
      
      enum WatchPage : String , CaseIterable  {
            case Exercise = "Exercise"
            case BloodOxygen = "BloodOxygen"
            case HeartRate = "HeartRate"
            case ExerciseRecord = "ExerciseRecord"
            case PhonePositioning = "PhonePositioning"
            case AlarmClock = "AlarmClock"
            case TakePhotos = "TakePhotos"
            case Meditation = "Meditation"
            case SleepRecord = "SleepRecord"
            case Weather = "Weather"
            case StopWatch = "StopWatch"
            case Music = "Music"
            case Countdown = "Countdown"
            case Setting = "Setting"
            case TodayOverview = "TodayOverview"
        }
        
      enum WeekStart : String , CaseIterable  {
             case Monday = "Monday"
             case Saturday = "Saturday"
             case Sunday = "Sunday"
      }

      enum VibrationIntensity : String , CaseIterable  {
             case Low = "Low"
             case Medium = "Medium"
             case High = "High"
      }
    

      enum WatchFaceDiaplayItem : String , CaseIterable  {
             case Time = "Time"
             case Bluetooth = "Bluetooth"
             case Power = "Power"
             case Step = "Step"
             case Date = "Date"
             case Week = "Week"
      }
    
    
    enum StateControlItem : String , CaseIterable  {
           case LoginReset = "LoginReset"
           case Disconnect = "Disconnect"
           case Unbind = "Unbind"
           case Restart = "Restart"
           case Reset = "Reset"
           case Shutdown = "Shutdown"
    }
    
    enum AppMessageItem : String , CaseIterable  {
        case All = "All"
        case Wechat = "Wechat"
        case SMS = "SMS"
        case IncomingCall = "IncomingCall"
        case Lestfit = "Lestfit"
    }
    
    enum FileUpdateItem : String, CaseIterable {
        case Firmware = "Firmware Update"
    }
    
    enum GotFileItem : String , CaseIterable  {
           case Log = "log"
           case MusicBackground = "music background"
           case CallerAvatar = "caller avatar"
           case WatchFace = "watch face"
           case AGPS = "agps"
           case GPS = "gps"
           case IotIcon = "iot icon"
    }
    
    enum IotDeviceItem : String,CaseIterable {
        case Headset = "Headset"
        case Socket = "Socket"
        case LightBulb = "SmartBulb"
        case AirConditioners = "AirConditioners"
        case Speaker = "SmartSpeaker"
    }
    
    enum TargetItem : String,CaseIterable {
        case Step = "Step"
        case Calories = "Calories"
        case Distance = "Distance"
        case StandingTime = "Standing Time"
        case ExerciseTime = "Exercise Time"
    }
    
    enum ReminderItem : String,CaseIterable{
        case DrinkWater = "Drink Water"
        case Meditation = "Meditation"
        case GoalAchieved = "Goal Achieved"
        case HeartRate = "Heart Rate"
        case Sedentary = "Sedentary"
    }
    
    enum ScaleUnitItem : String,CaseIterable {
        case Kg = "kg"
        case lb = "lb"
        case St = "st"
        case jin = "公斤"
        case gjin = "斤"
    }
    
    enum BgmQueryItem : String,CaseIterable {
        case sn = "SN"
        case unit = "Unit"
        case version = "Version"
        case history = "HistoryData"
    }
    

    enum TempMeasurementMode : String,CaseIterable{
        case adult = "Adult"
        case children = "Children"
        case ear = "Ear"
        case material = "Material"
    }
    
    enum TempMeasurementUnit : String,CaseIterable{
        case celsius = "摄氏温度"
        case fahrenheit = "华氏温度"
    }
    
    enum UserData : String,CaseIterable{
        case all = "All Users"
        case user1 = "User 1"
        case user2 = "User 2"
    }
    
    enum DeviceUsers : String,CaseIterable{
        case user1 = "User 1"
        case user2 = "User 2"
    }
    
    enum ScanFilter : String,CaseIterable{
        case allDevice = "All Devices"
        case thermometer = "Thermometer"
        case Oximeter = "Oximeter"
        case BloodPressureMeter = "BloodPressureMeter"
        case DigitalThermometer = "DigitalThermometer"
    }
}
