//
//  MenuItem.swift
//  BluetoothDemo
//
//  Created by CCX on 2020/7/24.
//  Copyright © 2020 sky. All rights reserved.
//

import Foundation

class MenuItem
{
    var title : String = "";
    var action : (()->Void)? ;
    
    init(name:String,funcName:(()->Void)?) {
        self.title = name;
        self.action=funcName;
    }
    
}
