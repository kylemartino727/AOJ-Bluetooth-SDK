//
//  StorageUtils.swift
//  BluetoothDemo
//
//  Created by CCX on 2020/8/3.
//  Copyright © 2020 sky. All rights reserved.
//

import Foundation
import CoreData
import UIKit

struct StorageUtils{
    @available(*,unavailable)
    private init(){}
    
    
    static func saveDevice(item : BTDeviceInfo) -> NSManagedObject?{
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return nil;
        }
        let managedContext = appDelegate.persistentContainer.viewContext;
        let entity = NSEntityDescription.entity(forEntityName: Constants.CoreData.modelName,in: managedContext)!;
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>.init(entityName: entity.name!);
        fetchRequest.predicate = NSPredicate.init(format: "broadcastId == %@",item.broadcastId!);
        
        do {
             let maths = try managedContext.fetch(fetchRequest);
             if(maths.count > 0){
                //删除旧记录
                for delItem in maths{
                    managedContext.delete(delItem as! NSManagedObject)
                }
            }
            
            let device = NSManagedObject(entity: entity,insertInto: managedContext);
            // set value to device obj
            device.setValue(item.deviceName, forKeyPath: Constants.PairedDevice.keyName);
            device.setValue(item.broadcastId, forKeyPath: Constants.PairedDevice.keyBroadcastId);
            device.setValue(Int(item.deviceType.rawValue), forKeyPath: Constants.PairedDevice.keyDeviceType);
            device.setValue(item.manufacturerData, forKeyPath: Constants.PairedDevice.keyManufacturerData);
            device.setValue(item.deviceSn, forKeyPath: Constants.PairedDevice.keyDeviceSn);
            device.setValue(item.deviceId, forKeyPath: Constants.PairedDevice.keyDeviceId);
            device.setValue(item.macAddress, forKeyPath: Constants.PairedDevice.keyMacAddress);
            device.setValue(item.protocolType, forKeyPath: Constants.PairedDevice.keyProtocolType);
            device.setValue(item.deviceUserNumber, forKeyPath: Constants.PairedDevice.keyUserNumber);
            
            try managedContext.save();
            return device;
        } catch let error as NSError {
            print("Could not save. \(error), \(error.userInfo)");
        }
        return nil;
    }
    
    static  func removeData(item: NSManagedObject){
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return ;
        }
        let managedContext = appDelegate.persistentContainer.viewContext;
        managedContext.delete(item);
        //save
        appDelegate.saveContext();
    }
    
}
