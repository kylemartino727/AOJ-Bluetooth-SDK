package com.aojmedical.devhelper.view;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import com.aojmedical.devhelper.model.BleDevice;

import java.util.ArrayList;

import com.aojmedical.devhelper.R;
import com.aojmedical.devhelper.utils.AppUtils;
import com.aojmedical.plugin.ble.data.BTDeviceInfo;
import com.aojmedical.plugin.ble.data.BTDeviceType;

public class DeviceAdapter extends ArrayAdapter implements Filterable {

    private Context context;
    private ArrayList<BleDevice> dataSources;

    public ArrayList<BleDevice> getDataSources() {
        return dataSources;
    }

    // View lookup cache
    private static class ViewHolder {
        TextView txtName;
        TextView txtMac;
        TextView txtRssi;
        ImageView imageView;
    }


    @SuppressWarnings("unchecked")
    public DeviceAdapter(Context context, ArrayList<BleDevice> modelsArrayList) {
        super(context, R.layout.list_device_item, modelsArrayList);
        this.context = context;
        this.dataSources = modelsArrayList;

    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        // Get the data item for this position
        BleDevice dataModel = (BleDevice) getItem(position);
        // Check if an existing view is being reused, otherwise inflate the view
        ViewHolder viewHolder; // view lookup cache stored in tag
        final View result;
        if (convertView == null) {
            viewHolder = new ViewHolder();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.list_device_item, parent, false);
            viewHolder.txtName = (TextView) convertView.findViewById(R.id.tv_device_name);
            viewHolder.txtMac = (TextView) convertView.findViewById(R.id.tv_device_mac);
            viewHolder.txtRssi = (TextView) convertView.findViewById(R.id.tv_device_rssi);
            viewHolder.imageView = (ImageView)convertView.findViewById(R.id.image_device);
            result=convertView;
            convertView.setTag(viewHolder);
        }
        else {
            viewHolder = (ViewHolder) convertView.getTag();
            result=convertView;
        }
        viewHolder.txtName.setText(dataModel.getName());
        if(dataModel.getName() == null || dataModel.getName().equalsIgnoreCase("")){
            viewHolder.txtName.setText("N/A");
        }
        viewHolder.txtMac.setText(dataModel.getMac());
        viewHolder.txtRssi.setText(dataModel.getRssi() + "");
        if(dataModel.getSource() == 0){
            viewHolder.txtRssi.setVisibility(View.GONE);
            viewHolder.txtMac.setText(AppUtils.formatMacAddress(dataModel.getMac()));
        }

        if(getDeviceType(dataModel.getType()) == BTDeviceType.Thermometer
                ||getDeviceType(dataModel.getType()) == BTDeviceType.DigitalThermometer ){
            viewHolder.imageView.setBackgroundResource(R.mipmap.ic_temp);
        }
        else if(getDeviceType(dataModel.getType()) == BTDeviceType.Oximeter ){
            viewHolder.imageView.setBackgroundResource(R.mipmap.ic_oximeter);
        }
        else{
            viewHolder.imageView.setBackgroundResource(R.mipmap.ic_bmp);
        }
        // Return the completed view to render on screen
        return convertView;
    }

    private BTDeviceType getDeviceType(int type){
        return BTDeviceType.getDeviceType(type);
    }

}
