package com.aojmedical.devhelper;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

import com.aojmedical.devhelper.databinding.FragmentConnectBinding;
import com.aojmedical.devhelper.model.BleDevice;
import com.aojmedical.devhelper.utils.AppConfig;
import com.aojmedical.devhelper.utils.AppUtils;
import com.aojmedical.devhelper.utils.DialogUtils;
import com.aojmedical.devhelper.utils.PermissionUtils;
import com.aojmedical.devhelper.view.BpmSettingView;
import com.aojmedical.devhelper.view.ModeConfigView;
import com.aojmedical.devhelper.view.SpO2AlarmView;
import com.aojmedical.plugin.ble.AHDevicePlugin;
import com.aojmedical.plugin.ble.OnSettingListener;
import com.aojmedical.plugin.ble.OnSyncingListener;
import com.aojmedical.plugin.ble.data.BTConnectState;
import com.aojmedical.plugin.ble.data.BTDeviceInfo;
import com.aojmedical.plugin.ble.data.BTDeviceSyncSetting;
import com.aojmedical.plugin.ble.data.BTDeviceType;
import com.aojmedical.plugin.ble.data.BTManagerStatus;
import com.aojmedical.plugin.ble.data.IDeviceData;
import com.aojmedical.plugin.ble.data.bpm.AHBpmConfig;
import com.aojmedical.plugin.ble.data.bpm.AHBpmConfigSetting;
import com.aojmedical.plugin.ble.data.bpm.AHBpmData;
import com.aojmedical.plugin.ble.data.bpm.AHBpmErrorData;
import com.aojmedical.plugin.ble.data.bpm.AHBpmProcessData;
import com.aojmedical.plugin.ble.data.po.AHPlethysmogram;
import com.aojmedical.plugin.ble.data.po.AHSpO2AlarmSetting;
import com.aojmedical.plugin.ble.data.po.AHSpO2SyncSetting;
import com.aojmedical.plugin.ble.data.temp.AHTempCmd;
import com.aojmedical.plugin.ble.data.temp.AHTempSetting;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class ConnectFragment extends Fragment {

    private static final String TAG = "DevHelper";

    private BleDevice mDevice;
    private FragmentConnectBinding binding;
    private FloatingActionButton fab;
    private TextView deviceNameView;
    private TextView stateTextView;
    private TextView logTextView;
    private TextView batteryTextView;
    private TextView newDataTextView;
    private ProgressBar stateProgressBar;
    private Handler mainHandler;
    private int mDataIndex;
    private ProgressDialog upgradingDialog;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        if(getArguments().get(BleDevice.KEY) != null){
            this.mDevice = (BleDevice) getArguments().get(BleDevice.KEY);
            debugMessage("ConnectFragment >> "+this.mDevice.toString());
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState
    ) {
        binding = FragmentConnectBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.fab = (FloatingActionButton) getActivity().findViewById(R.id.fab);
        this.fab.setVisibility(View.GONE);
        //init view
        this.deviceNameView = (TextView) view.findViewById(R.id.device_name_tv);
        this.stateTextView = (TextView) view.findViewById(R.id.device_connect_state_tv);
        this.newDataTextView = (TextView) view.findViewById(R.id.new_data_text_view);
        this.stateProgressBar = (ProgressBar) view.findViewById(R.id.syncing_progress_bar);
        this.logTextView = (TextView) view.findViewById(R.id.device_log_text_view);
        this.batteryTextView = (TextView) view.findViewById(R.id.device_battery_tv);
        this.logTextView.setVisibility(View.VISIBLE);
        this.logTextView.setText("");
        this.batteryTextView.setText("");
        this.stateProgressBar.setVisibility(View.GONE);
        //init
        this.initView();
    }


    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onResume() {
        super.onResume();
        //connect device
        connectDevice();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        //stop sync & listener
        AHDevicePlugin.getInstance().stopAutoConnect();
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        if(this.mDevice.getType() == BTDeviceType.Oximeter.getValue()){
            //pulse oximeter
            inflater.inflate(R.menu.menu_oximeter, menu);
        }
        else if(this.mDevice.getType() == BTDeviceType.BloodPressureMeter.getValue()){
            //blood pressure meter
            inflater.inflate(R.menu.menu_bpm, menu);
        }
        else inflater.inflate(R.menu.menu_temp, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if(id == R.id.action_share_log){
            return AppUtils.shareLog(getActivity(),this.mDevice.getMac());
        }
        if (id == R.id.action_start_measuring) {
            if(this.mDevice.getType() == BTDeviceType.BloodPressureMeter.getValue()){
                //blood pressure meter
                return this.pushSetting(new AHBpmConfigSetting(AHBpmConfig.StartMeasuring));
            }
            else return this.pushSetting(AHTempCmd.StartMeasuring);
        }
        if (id == R.id.action_sync_data) {
            return this.pushSetting(AHTempCmd.SyncData);
        }
        if (id == R.id.action_clear_data) {
            return this.pushSetting(AHTempCmd.ClearData);
        }
        if (id == R.id.action_query_status) {
            return this.pushSetting(AHTempCmd.QueryStatus);
        }
        if(id == R.id.action_clear_screen){
            this.logTextView.setText("");
            return true;
        }
        if(id == R.id.action_mode_config){
            return ModeConfigView.show(this.mDevice.getMac(),settingListener);
        }
        if(id == R.id.action_start_sync){
            return pushSetting(new AHSpO2SyncSetting(true));
        }
        if(id == R.id.action_stop_sync){
            return pushSetting(new AHSpO2SyncSetting(false));
        }
        if(id == R.id.action_stop_measuring){
            return this.pushSetting(new AHBpmConfigSetting(AHBpmConfig.StopMeasuring));
        }
        if(id == R.id.action_voice_control){
            return BpmSettingView.showVoiceControl(this.mDevice.getMac(),settingListener);
        }
        if(id == R.id.action_switch_user){
            return BpmSettingView.showSwitchUser(this.mDevice.getMac(),settingListener);
        }
        if(id == R.id.action_sync_user_data){
            return BpmSettingView.showUserDataSync(this.mDevice.getMac(),settingListener);
        }
        if(id == R.id.action_remove_user_data){
            return BpmSettingView.showUserDataRemove(this.mDevice.getMac(),settingListener);
        }
        if(id == R.id.action_voice_prompt){
            return this.pushSetting(new AHBpmConfigSetting(AHBpmConfig.CancelVoicePrompt));
        }
        if (id == R.id.action_start_measuring_da) {
            return this.pushSetting(AHTempCmd.NewStartMeasuring);
        }
        if (id == R.id.action_sync_data_d9) {
            return this.pushSetting(AHTempCmd.NewSyncData);
        }
        if (id == R.id.action_time_sync_d8) {
            return this.pushSetting(AHTempCmd.NewSyncTime);
        }
        if(id == R.id.action_bpm_get_sn){
            return this.pushSetting(new AHBpmConfigSetting(AHBpmConfig.GetSn));
        }
        if(id == R.id.action_bpm_online_check){
            return this.pushSetting(new AHBpmConfigSetting(AHBpmConfig.OnlineCheck));
        }
        if(id == R.id.action_bpm_power_off){
            return this.pushSetting(new AHBpmConfigSetting(AHBpmConfig.PowerOff));
        }
        if(id == R.id.action_sync_bpm_time){
            return this.pushSetting(new AHBpmConfigSetting(AHBpmConfig.SystemTime));
        }
        if(id == R.id.action_device_state){
            return this.pushSetting(new AHBpmConfigSetting(AHBpmConfig.StatusSync));
        }
        return super.onOptionsItemSelected(item);
    }



    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private void initView(){
        this.mainHandler = new Handler(getActivity().getMainLooper());
        String title = String.format("%s[%s]",this.mDevice.getName(),this.mDevice.getMac());
        this.deviceNameView.setText(title);
    }


    /**
     * 连接设备
     */
    private void connectDevice() {
        if (!AHDevicePlugin.getInstance().isSupportBLE()) {
            DialogUtils.showDialog(getActivity(), "Prompt", "Does not support Bluetooth low energy");
            return;
        }
        if (!AHDevicePlugin.getInstance().isBluetoothAvailable()) {
            DialogUtils.showDialog(getActivity(), "Prompt", "Please turn on Bluetooth");
            return;
        }
        if (checkConnection()) {
            AHDevicePlugin.getInstance().resetSyncingListener(mDataCallback);
            stateProgressBar.setVisibility(View.GONE);
            stateTextView.setTextColor(Color.BLUE);
            stateTextView.setText(getResources().getString(R.string.state_connected));
            return;
        }
        if (AHDevicePlugin.getInstance().getManagerStatus() == BTManagerStatus.Syncing) {
            return;
        }
        AHDevicePlugin.getInstance().stopAutoConnect();
        //clear measure device list
        AHDevicePlugin.getInstance().setDevices(null);
        //add target measurement device
        AHDevicePlugin.getInstance().addDevice(AppUtils.toDevice(this.mDevice));
        //start data syncing service
        AHDevicePlugin.getInstance().startAutoConnect(mDataCallback);
        //update connect state
        updateDeviceConnectState(BTConnectState.Connecting);
    }


    /**
     * 连接状态检测
     * @return
     */
    private boolean checkConnection(){
        BTManagerStatus status =  AHDevicePlugin.getInstance().getManagerStatus();
        BTConnectState connectState = AHDevicePlugin.getInstance().checkConnectState(this.mDevice.getMac());
        return  status == BTManagerStatus.Syncing && connectState  == BTConnectState.ConnectSuccess;
    }

    /**
     * Debug message
     * @param msg
     */
    private void debugMessage(String msg){
        Log.e(TAG,msg);
    }


    /**
     * 提示信息
     * @param msg
     */
    private void showToastMessage(String msg) {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getActivity().getApplicationContext(),msg,Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * 连接状态更新
     * @param state
     */
    private void updateDeviceConnectState(BTConnectState state) {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (getActivity() == null) {
                    return;
                }
                if (BTConnectState.ConnectSuccess == state) {
                    stateProgressBar.setVisibility(View.GONE);
                    stateTextView.setTextColor(Color.BLUE);
                    newDataTextView.setVisibility(View.VISIBLE);
                    newDataTextView.setText(getResources().getString(R.string.str_no_data));
                    newDataTextView.setTextColor(Color.GRAY);
                    logTextView.setText("");
                    stateTextView.setText(getResources().getString(R.string.state_connected));
                } else {
                    mDataIndex = 0;
                    if (BTConnectState.Disconnect == state) {
                        stateTextView.setTextColor(Color.RED);
                        stateTextView.setText(getResources().getString(R.string.state_disconnect));
                    } else {
                        stateTextView.setTextColor(Color.GRAY);
                        stateTextView.setText(getResources().getString(R.string.state_connecting));
                    }
                    //
                    if (AHDevicePlugin.getInstance().getManagerStatus() == BTManagerStatus.Syncing) {
                        stateProgressBar.setVisibility(View.VISIBLE);
                        newDataTextView.setVisibility(View.GONE);
                    } else {
                        newDataTextView.setVisibility(View.GONE);
                        stateProgressBar.setVisibility(View.GONE);
                        stateTextView.setTextColor(Color.BLACK);
                        stateTextView.setText(getResources().getString(R.string.state_unknown));
                    }
                }
            }
        });
    }

    /**
     * 更新数据提示信息
     */
    private void updateNewDatMessage() {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (getActivity() == null) {
                    return;
                }
                newDataTextView.clearAnimation();
                mDataIndex++;
                String newsStr = "%@ New data";//getResources().getString(R.string.str_new_data);
                newsStr = newsStr.replace("%@", mDataIndex + "");
                newDataTextView.setText(newsStr);
                newDataTextView.setTextColor(Color.RED);
                newDataTextView.setAnimation(AnimationUtils.loadAnimation(getActivity(), android.R.anim.fade_in));
            }
        });
    }

    /**
     * 展示设备的测量数据
     *
     * @param obj
     */
    private void showDeviceMeasuringData(final Object obj, final String srcData) {
        if (obj == null || getActivity() == null) {
            return;
        }
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                logTextView.append("\r\n");
                logTextView.append(Html.fromHtml("<font color='red'>" + "-----------------------" + "</font>"));
                logTextView.append("\r\n");
                if (srcData != null) {
                    logTextView.append("srcData=" + srcData + "\r\n");
                }
                logTextView.append("\r\n");
                logTextView.append(AppUtils.formatString(obj.toString()));
                logTextView.append("\r\n");
            }
        });
    }


    /**
     * Device measurement data synchronization callback object
     */
    private OnSyncingListener mDataCallback = new OnSyncingListener() {
        @Override
        public void onStateChanged(String broadcastId, BTConnectState state) {
            //Device Connection Status
            updateDeviceConnectState(state);
        }

        @Override
        public void onDeviceInfoUpdate(String broadcastId, BTDeviceInfo lsDevice) {
            //refresh menu
            mainHandler.post(new Runnable() {
                @Override
                public void run() {
                    getActivity().invalidateOptionsMenu();
                }
            });
        }

        @Override
        public void onDeviceDataUpdate(String devMac, IDeviceData obj) {
            updateNewDatMessage();
            showDeviceMeasuringData(obj, AppUtils.byte2hexString(obj.getSrcData()));
            handleData(obj);
        }
    };

    /**
     * Setting Listener
     */
    private OnSettingListener settingListener = new OnSettingListener() {
        @Override
        public void onSuccess(String s) {
            showToastMessage(String.format("Sync setting succeeded"));
        }

        @Override
        public void onFailure(int error) {
            showToastMessage(String.format("Sync settings failed:%d",error));
        }
    };

    /**
     * 指令推送
     */
    private boolean pushSetting(AHTempCmd opCmd){
        AHTempSetting setting = new AHTempSetting(opCmd);
        AHDevicePlugin.getInstance().pushSetting(this.mDevice.getMac(), setting, settingListener);
        return true;
    }

    private boolean pushSetting(BTDeviceSyncSetting setting){
        AHDevicePlugin.getInstance().pushSetting(this.mDevice.getMac(), setting, settingListener);
        return true;
    }


    /**
     * 显示升级提示对话框
     *
     * @param title
     * @param message
     */
    private void showProgressingDialog(String title, final String message, boolean cancelable,boolean isPair) {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                ContextThemeWrapper ctw = new ContextThemeWrapper(getActivity(), android.R.style.Theme_Holo_Light);
                upgradingDialog = new ProgressDialog(ctw);
                upgradingDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                upgradingDialog.setCanceledOnTouchOutside(false);
                upgradingDialog.setCancelable(cancelable);
                upgradingDialog.setTitle(title);
                upgradingDialog.setMessage(message);

                upgradingDialog.setButton(ProgressDialog.BUTTON_NEGATIVE, "Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //停止测试
                    }
                });
                upgradingDialog.show();
            }
        });
    }

    /**
     * 显示升级提示信息
     *
     * @param msg
     */
    private void updateProgressMessage(final String msg) {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (upgradingDialog != null && upgradingDialog.isShowing()) {
                    upgradingDialog.setMessage(msg);
                }
            }
        });
    }

    /**
     * 取消升级提示Dialog
     */
    private void cancelProgressingDialog(String tag) {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (upgradingDialog != null && upgradingDialog.isShowing()) {
                    upgradingDialog.dismiss();
                }
            }
        });
    }


    /**
     * 读写手机SD文件权限检测
     * @return
     */
    private boolean checkPermission(){
        String permission = Manifest.permission.WRITE_EXTERNAL_STORAGE;
        if(!PermissionUtils.checkPermission(getActivity().getApplicationContext(),permission)){
            ActivityCompat.requestPermissions(getActivity(),
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 0);
            return false;
        }
        return true;
    }

    private void updateData(String str) {
        if(upgradingDialog != null && upgradingDialog.isShowing()){
            updateProgressMessage(str);
        }
        else{
            showProgressingDialog(null,str,false,false);
        }
    }


    private void handleData(IDeviceData obj) {
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if(obj instanceof AHBpmProcessData){
                    AHBpmProcessData pressure  = (AHBpmProcessData)obj;
                    //更新当前压力数据
                    updateData(String.format("Value=%d，State=%d",pressure.getPressure(),pressure.getPulseState()));
                }
                else if(obj instanceof AHBpmData){
                    cancelProgressingDialog(null);
                }
                else if(obj instanceof AHBpmErrorData){
                    AHBpmErrorData error = (AHBpmErrorData) obj;
                    cancelProgressingDialog(null);
                    DialogUtils.showDialog(getActivity(),null,"Failed to measure,ERR"+error.getCode());
                }
            }
        });
    }

}