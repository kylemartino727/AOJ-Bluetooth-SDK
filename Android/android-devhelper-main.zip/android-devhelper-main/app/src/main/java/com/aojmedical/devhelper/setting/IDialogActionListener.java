package com.aojmedical.devhelper.setting;

import android.content.Intent;

import java.util.List;

public abstract class IDialogActionListener {

	public void onSingleChoiceItemValue(int index){};
	
	public void onTimeChoiceValue(int hour,int minute){};
	
	public void onTitleAndTimeChoiceValue(String title,int hour,int minute){};

	public void onMultiChoiceItemValue(List<Integer> items){};
	
	public void onIntentResults(Intent intent){};
	
	public void onSettingItems(List<SettingItem> items){};
	

	public void onItemObjectCreate(Object obj){};

	public void onDialogSaveAction(){};

}
