package com.aojmedical.devhelper.utils;

import android.util.Log;

public class AppLogger {

    private static final String TAG = "Dev-BLE";

    public static void log(String msg){
        Log.d(TAG,String.format("[App]-%s",msg));
    }
}
