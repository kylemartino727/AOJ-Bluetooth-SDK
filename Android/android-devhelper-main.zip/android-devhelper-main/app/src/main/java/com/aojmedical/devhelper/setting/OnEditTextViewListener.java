package com.aojmedical.devhelper.setting;

import android.widget.EditText;

public interface OnEditTextViewListener {

	void onEditTextResults(EditText editView,SettingItem item);
}
