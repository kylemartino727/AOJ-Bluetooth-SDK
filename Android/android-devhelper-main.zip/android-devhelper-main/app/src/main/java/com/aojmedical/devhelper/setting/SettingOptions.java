package com.aojmedical.devhelper.setting;

public enum SettingOptions {

    NumberPicker,
    TimePicker,
    TimeSecondPicker,
    SingleChoice,
    MultipleChoice,
    Text,
    Image,
    File,
    Number,
    List,
}
