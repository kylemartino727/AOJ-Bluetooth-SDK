package com.aojmedical.devhelper.utils;

import static androidx.core.content.FileProvider.getUriForFile;

import android.app.Activity;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.Environment;
import android.util.Log;

import androidx.core.app.ShareCompat;
import androidx.core.content.FileProvider;

import com.aojmedical.devhelper.model.BleDevice;
import com.aojmedical.plugin.ble.AHDevicePlugin;
import com.aojmedical.plugin.ble.data.BTDeviceInfo;



import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class AppUtils {


    /**
     * Get Version
     * @param context
     * @return
     */
    public static String getVersion(Context context){
        try{
            PackageInfo info = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            return info.versionName;
        }catch (Exception e){
            e.printStackTrace();
            return "---";
        }
    }

    /**
     * 创建log文件目录
     * @param context
     * @return
     */
    public static String createPortraitUrl(Context context, String filePath) {
        try {
            boolean sdCardExist = Environment.getExternalStorageState().equals(
                    android.os.Environment.MEDIA_MOUNTED);
            StringBuffer url = new StringBuffer();
            if (sdCardExist) {
                url.append(Environment.getExternalStorageDirectory().getPath()
                        + File.separator);
            } else {
                url.append(context.getFilesDir().getAbsolutePath()
                        + File.separator);
            }
            url.append(filePath + File.separator);
            File file = new File(url.toString());
            if (!file.exists()) {
                file.mkdirs();
            }
            return url.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    /**
     * 格式化字符串信息
     * @param msg
     * @return
     */
    public static  String formatString(String msg) {
        String str=msg.replace("[", "\r\n");
        str=str.replace(",", ",\r\n");
        str=str.replace("]", "\r\n");
        return str;
    }

    /**
     * 根据长度切割字符串
     * @param str
     * @param length
     * @return
     */
    public static List<String> splitString(String str,int length) {
        if(str == null || str.length() <= 0){
            return null;
        }
        List<String> list = new ArrayList<String>(
                (str.length() + length - 1) / length);
        for (int start = 0; start < str.length(); start += length) {
            list.add(str.substring(start, Math.min(str.length(), start + length)));
        }
        return list;
    }

    /**
     * 设备MAC格式化
     * @param macStr
     * @return
     */
    public static String formatMacAddress(String macStr){
        if(macStr == null || macStr.length() <= 0){
            return macStr;
        }
        if(macStr.contains(":")){
            return macStr;
        }
        List<String> items = splitString(macStr,2);
        if(items == null){
            return macStr;
        }
        int index = items.size();
        StringBuffer buffer = new StringBuffer();
        for(String item:items){
            buffer.append(item);
            if(index > 1){
                buffer.append(":");
                index --;
            }
        }
        return buffer.toString().toUpperCase();
    }

    /**
     * 将字节数组转换成16进制数据,带格式转换 e.g 00-AA-BB
     * @param data
     * @return
     */
    public static String byte2hexString(byte[] data)
    {
        if(data==null){
            return "";
        }
        String hs = "";
        String stmp = "";
        for (int n=0;n<data.length;n++)
        {
            stmp=(Integer.toHexString(data[n]&0XFF));
            if(stmp.length()==1){
                hs=hs+"0"+stmp;
            }
            else{
                hs=hs+stmp;
            }
            if(n<data.length-1){
                hs=hs+"";
            }
        }
        return   hs.toUpperCase();
    }


    /**
     * 设备对象转换
     * @param device
     * @return
     */
    public static BTDeviceInfo toDevice(BleDevice device){
        BTDeviceInfo btDevice = new BTDeviceInfo();
        btDevice.setMacAddress(device.getMac());
        btDevice.setDeviceName(device.getName());
        btDevice.setDeviceType(device.getType());
        return btDevice;
    }

    /**
     * BTDeviceInfo to BleDevice
     * @return
     */
    public static BleDevice toBleDevice(BTDeviceInfo btDevice){
        if(btDevice == null || btDevice.getMacAddress() == null){
            return null;
        }
        BleDevice device = new BleDevice();
        device.setMac(btDevice.getMacAddress());
        device.setType(btDevice.getDeviceType());
        device.setRssi(btDevice.getRssi());
        device.setName(btDevice.getDeviceName());
        device.setSource(1);
        return device;
    }

    /**
     * 日志分享
     * @param activity
     * @param mac
     * @return
     */
    public static boolean shareLog(Activity activity, String mac) {
        File file = AHDevicePlugin.getInstance().exportLogFile(mac);
        if(file == null){
            AppLogger.log("no file to share.");
            return false;
        }
        AppLogger.log("Share File="+file.getAbsolutePath());
        Uri uri = null;
        int sdkInt = android.os.Build.VERSION.SDK_INT;
        if (sdkInt >= 24) {
            //若SDK大于等于24  获取uri采用共享文件模式
            uri = getUriForFile(activity, "com.aojmedical.devhelper.fileprovider", file);
        } else {
            uri = Uri.fromFile(file);
        }
        Intent intent = ShareCompat.IntentBuilder.from(activity)
                .setStream(uri) // uri from FileProvider
                .setType("text/html")
                .getIntent()
                .setAction(Intent.ACTION_SEND) //Change if needed
                .setDataAndType(uri, "text/*")
                //.setPackage("com.tencent.mm")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                        | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        activity.startActivity(intent);
        return true;
    }

}
