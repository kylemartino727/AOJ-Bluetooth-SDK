package com.aojmedical.devhelper.chart;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.LimitLine;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.XAxis.XAxisPosition;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.github.mikephil.charting.formatter.IValueFormatter;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.github.mikephil.charting.utils.ViewPortHandler;

public class ChartDataActivity {

//	private static final int MIN_VALUE=-20;
//	private static final int MAX_VALUE=600;
//
//
//	private LineChart mChart;
//	protected Typeface mTfLight;
//	protected Typeface mTfRegular;
//	private List<BloodGlucoseData> mListItems;
//	private DeviceDataAdapter mAdapter;
//	private ListView mPullListView;
//	private LinearLayout avgValueLayout;
//	private TextView avg7TextView,avg14TextView,avg28TextView,dataCountTextView;
//
//	@Override
//	protected void onCreate(Bundle savedInstanceState) {
//		super.onCreate(savedInstanceState);
//		setCenterView(R.layout.activity_blood_glucose_data);
//		avgValueLayout=(LinearLayout) findViewById(R.id.avg_value_layout);
//		avg7TextView=(TextView)findViewById(R.id.avg_7day_tv);
//		avg14TextView=(TextView)findViewById(R.id.avg_14day_tv);
//		avg28TextView=(TextView)findViewById(R.id.avg_28day_tv);
//		avgValueLayout.setVisibility(View.GONE);
//		dataCountTextView=(TextView)findViewById(R.id.data_count_text_view);
//		initChartView();
//		initListView();
//	}
//
//
//
//
//	@Override
//	protected void onResume()
//	{
//		super.onResume();
//		//set test data
//		showBloodGlucoseData();
//	}
//
//
//
//
//
//	@Override
//	protected void onDestroy() {
//		super.onDestroy();
//		mListItems.clear();
//		mAdapter.clear();
//	}
//
//
//
//
//	/**
//	 * 初始化数据列表
//	 */
//	private void initListView() {
//		mPullListView=(ListView)findViewById(R.id.data_list_view);
//		mListItems=new ArrayList<BloodGlucoseData>();
//		mAdapter = new DeviceDataAdapter(getApplicationContext(), (ArrayList<BloodGlucoseData>) mListItems);
//		mPullListView.setLongClickable(false);
//		mPullListView.setAdapter(mAdapter);
//	}
//
//
//	/**
//	 * 初始化图表
//	 */
//	private void initChartView() {
//		mTfLight = Typeface.createFromAsset(getAssets(), "OpenSans-Light.ttf");
//		mChart = (LineChart) findViewById(R.id.blood_glucose_data_chart);
//		mChart.setOnChartValueSelectedListener(this);
//		mChart.setDrawGridBackground(false);
//		mChart.getDescription().setEnabled(false);
//		// add an empty data object
//		//		mChart.setData(new LineData());
//		//		mChart.invalidate();
//		Legend l = mChart.getLegend();
//		l.setForm(Legend.LegendForm.NONE);
//		// no description text
//		mChart.getDescription().setEnabled(false);
//		// enable touch gestures
//		mChart.setTouchEnabled(true);
//		// enable scaling and draggin
//		mChart.setDrawGridBackground(false);
//		mChart.setHighlightPerDragEnabled(true);
//		//        // set an alternative background color
//		mChart.setViewPortOffsets(30f, 5f, 25f, 10f);
//		mChart.fitScreen();
//
//		XAxis xAxis = mChart.getXAxis();
//		xAxis.setPosition(XAxisPosition.TOP_INSIDE);
//		xAxis.setTypeface(mTfLight);
//		xAxis.setTextSize(10f);
//		xAxis.setTextColor(Color.WHITE);
//		xAxis.setDrawAxisLine(false);
//		xAxis.setDrawGridLines(false);
//		xAxis.setCenterAxisLabels(false);
//		xAxis.setGranularity(24*1f); // one hour
//		xAxis.setValueFormatter(new IAxisValueFormatter() {
//
//			private SimpleDateFormat mFormat = new SimpleDateFormat("MM/dd");
//
//			@Override
//			public String getFormattedValue(float value, AxisBase axis) {
//
//				long millis = TimeUnit.HOURS.toMillis((long) value);
//				return mFormat.format(new Date(millis));
//			}
//		});
//
//		YAxis leftAxis = mChart.getAxisLeft();
//		leftAxis.setTypeface(mTfLight);
//		leftAxis.setDrawGridLines(false);
//		leftAxis.setGranularityEnabled(false);
//		leftAxis.setAxisMinimum(MIN_VALUE);
//		leftAxis.setAxisMaximum(MAX_VALUE);
//		leftAxis.setTextColor(Color.WHITE);
//		leftAxis.setEnabled(false);
//		leftAxis.setYOffset(100f);
//		leftAxis.setValueFormatter(new IAxisValueFormatter() {
//
//			@Override
//			public String getFormattedValue(float value, AxisBase arg1) {
//				if(value==0){
//					return "0";
//				}
//				return ""+(int)value;
//			}
//		});
//		YAxis rightAxis = mChart.getAxisRight();
//		rightAxis.setEnabled(false);
//
//		mChart.centerViewToY(50, YAxis.AxisDependency.LEFT);
//
//		mChart.setExtraBottomOffset(-2);
//		mChart.moveViewToX(2);  //将左边的边放到指定的位置，参数是（float xindex）
//		mChart.animateX(2000, Easing.EasingOption.EaseInOutQuart);
//	}
//
//
//
//	private void showBloodGlucoseData()
//	{
//		List<BloodGlucoseData> allDatas=DevicePluginManager.getInstance().getAllHistoryData();
//		if(allDatas==null || allDatas.size()==0){
//			mChart.setNoDataText("无历史数据");
//			mChart.setNoDataTextColor(Color.WHITE);
//			avgValueLayout.setVisibility(View.GONE);
//			return ;
//		}
//		for(BloodGlucoseData data:allDatas){
//			Log.e("LS-BLE", "history data >> "+data.toString()+"; srcSize="+allDatas.size());
//		}
//		//获取所有数据的图表显示
//		List<BloodGlucoseData> chartDatas=DeviceDataUtils.getLastDataWithCount(allDatas, allDatas.size());
//		//计算平均值
//		avgValueLayout.setVisibility(View.VISIBLE);
//		float avg7day=DeviceDataUtils.getAvgValue(allDatas, 7);
//		float avg14day=DeviceDataUtils.getAvgValue(allDatas, 14);
//		float avg28day=DeviceDataUtils.getAvgValue(allDatas, 30);
//		//更新显示
//		avg7TextView.setText((int)avg7day+"");
//		avg14TextView.setText((int)avg14day+"");
//		avg28TextView.setText((int)avg28day+"");
//
//		//更新图表数据
//		updateChartDataTest(chartDatas);
//
//		//更新列表数据
//		updateListData(allDatas);
//	}
//
//
//	/**
//	 * 更新列表数据
//	 * @param allDatas
//	 */
//	private void updateListData(final List<BloodGlucoseData> allDatas) {
//		runOnUiThread(new Runnable() {
//			@SuppressWarnings("unchecked")
//			@Override
//			public void run() {
//				if(allDatas==null || allDatas.size()==0){
//					return ;
//				}
//				//对数据进行排序
//				Collections.sort(allDatas,Collections.reverseOrder());
//				//加入列表
//				mListItems =allDatas;
//				dataCountTextView.setVisibility(View.VISIBLE);
//				dataCountTextView.setText("总数:"+allDatas.size());
//				LsBleManager.getInstance().setLogMessage("show hisroty data count="+allDatas.size());
//				for(BloodGlucoseData data:allDatas){
//					if(data!=null){
//						String time=DateUtil.getDateString(data.getMeasureDate());
//						LsBleManager.getInstance().setLogMessage("hisroty data >>"+data.getConcentration()+"; time ="+time+"; recordNo="+data.getRecordNo());
//						mAdapter.add(data);
//						mAdapter.notifyDataSetChanged();
//					}
//				}
//			}
//		});
//	}
//
//
//
//	/**
//	 * 更新图表数据
//	 * @param chartDatas
//	 */
//	private void updateChartDataTest(final List<BloodGlucoseData> chartDatas)
//	{
//		runOnUiThread(new Runnable() {
//			@Override
//			public void run() {
//				if(chartDatas==null || chartDatas.size()==0){
//					mChart.setNoDataText("无历史数据");
//					mChart.setNoDataTextColor(Color.WHITE);
//					return ;
//				}
//				mChart.setNoDataText("");
//				ArrayList<Entry> yValArray = new ArrayList<Entry>();
//				List<TimeChartItem> chartItems=DeviceDataUtils.getTimeChartItem(chartDatas, 0);
//				for(TimeChartItem item:chartItems){
//					yValArray.add(new Entry(item.getxValue(), item.getyValue())); // add one entry per hour
//				}
//				// create a dataset and give it a type
//				LineDataSet set1 = new LineDataSet(yValArray, "");
//				set1.setColor(Color.WHITE);
//				set1.setCircleColor(Color.WHITE);
//				set1.setLineWidth(1.5f);
//				set1.setCircleSize(3f);
//				set1.setDrawCircleHole(true);
//				set1.setDrawCircles(true);
//				set1.setFillAlpha(65);
//				set1.setFillColor(Color.WHITE);
//				set1.setDrawHorizontalHighlightIndicator(false);
//				set1.setDrawVerticalHighlightIndicator(true);
//				set1.setHighLightColor(Color.WHITE);
////				set1.setCircleRadius(4f);
//				set1.setValueFormatter(new IValueFormatter() {
//
//					@Override
//					public String getFormattedValue(float value, Entry arg1, int arg2,
//							ViewPortHandler arg3) {
//						// TODO Auto-generated method stub
//						return (int)value+"";
//					}
//				});
//				// create a data object with the datasets
//				LineData data = new LineData(set1);
//				data.setValueTextColor(Color.WHITE);
//				data.setValueTextSize(9f);
//
//				data.notifyDataChanged();
//
//
//				// set data
//				mChart.setData(data);
//				mChart.notifyDataSetChanged();
//				mChart.invalidate();
//			}
//		});
//	}
//
//
//	@Override
//	public void onNothingSelected() {
//		// TODO Auto-generated method stub
//
//	}
//
//	@Override
//	public void onValueSelected(Entry arg0, Highlight arg1) {
//		// TODO Auto-generated method stub
//
//	}
//
//
//
//	@Override
//	protected void initHeader() {
//		setHeader_LeftImage(R.mipmap.btn_back);
//		setHeader_Title("血糖");
//		setHeader_Title_Color(Color.WHITE);
//		setHeaderBackground(R.color.weight_title_color);
//		layout_left.setOnClickListener(this);
//		layout_left.setOnClickListener(this);
//		layout_more.setVisibility(View.GONE);
//	}
//
//
//	@Override
//	public void onClick(View view)
//	{
//		switch (view.getId())
//		{
//		case R.id.layout_left:{
//			finish();
//		}break;
//		}
//	}
}
