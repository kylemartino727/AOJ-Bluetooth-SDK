package com.aojmedical.devhelper;

import android.os.Bundle;

import com.aojmedical.devhelper.db.StoreManager;
import com.aojmedical.devhelper.model.BleDevice;
import com.aojmedical.devhelper.setting.SettingPanel;
import com.aojmedical.devhelper.utils.AppUtils;
import com.aojmedical.devhelper.utils.DialogUtils;
import com.aojmedical.devhelper.utils.PermissionUtils;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.View;

import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.aojmedical.devhelper.databinding.ActivityMainBinding;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration appBarConfiguration;
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setSupportActionBar(binding.toolbar);

        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        appBarConfiguration = new AppBarConfiguration.Builder(navController.getGraph()).build();
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);

        binding.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle args = new Bundle();
                NavHostFragment.findNavController(getFragment()).navigate(R.id.action_add_device_fragment,args);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        PermissionUtils.requestAll(this);
        SettingPanel.init(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId()){
            case R.id.action_version:{
                String title = getResources().getString(R.string.action_settings);
                String msg = AppUtils.getVersion(this.getApplicationContext());
                DialogUtils.showDialog(this,title,msg);
                //SettingPanel.showChart();
                return true;
            }
            default:{
                return false;
            }
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, appBarConfiguration)
                || super.onSupportNavigateUp();
    }

    private MyDevicesFragment getFragment(){
        NavHostFragment navHostFragment = (NavHostFragment) getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment_content_main);
        if(navHostFragment.getChildFragmentManager()!=null){
            for (Fragment it: navHostFragment.getChildFragmentManager().getFragments()) {
                if(it instanceof MyDevicesFragment){
                    MyDevicesFragment fragment = (MyDevicesFragment) it;
                    return fragment;
                }
            }
        }
        return null;
    }

}