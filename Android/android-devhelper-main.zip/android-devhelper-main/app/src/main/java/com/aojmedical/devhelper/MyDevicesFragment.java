package com.aojmedical.devhelper;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.aojmedical.devhelper.databinding.FragmentDevicesBinding;
import com.aojmedical.devhelper.db.StoreManager;
import com.aojmedical.devhelper.model.BleDevice;
import com.aojmedical.devhelper.view.DeviceAdapter;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MyDevicesFragment extends Fragment {

    private static final String TAG = "AOJ-BLE";
    private FragmentDevicesBinding binding;
    private Handler mainHandler;
    private ListView listView;
    private DeviceAdapter deviceAdapter;
    private ArrayList<BleDevice> bleDevices;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        binding = FragmentDevicesBinding.inflate(inflater, container, false);
        this.mainHandler = new Handler(getActivity().getMainLooper());
        return binding.getRoot();
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        FloatingActionButton fab = (FloatingActionButton) getActivity().findViewById(R.id.fab);
        if(fab != null){
            fab.setVisibility(View.VISIBLE);
            fab.setImageResource( android.R.drawable.ic_input_add);
            fab.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Bundle args = new Bundle();
                    NavHostFragment.findNavController(MyDevicesFragment.this).navigate(R.id.action_add_device_fragment,args);
                }
            });
        }
        this.listView = view.findViewById(R.id.list_devices);
        this.bleDevices = new ArrayList<>();
        this.deviceAdapter = new DeviceAdapter(this.getContext(),bleDevices);
        this.listView.setAdapter(this.deviceAdapter);
        this.listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                debugMessage("onItemClick >> "+bleDevices.get(position).toString());
                Bundle args = new Bundle();
                args.putParcelable(BleDevice.KEY,bleDevices.get(position));
                NavHostFragment.findNavController(MyDevicesFragment.this).navigate(R.id.action_to_connect_fragment,args);
            }
        });
        this.listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long l) {
                debugMessage("onItemLongClick >> "+bleDevices.get(position).toString());
                String msg = "Remove the device now ?";
                showConfirmDialog(getContext(),"Prompt",msg,bleDevices.get(position));
                return true;
            }
        });
        //加载本地设备列表
        loadTestDevice();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }


    /**
     * 设备加载测试
     */
    public void loadTestDevice(){
        this.deviceAdapter.clear();
        List<BleDevice> devices = StoreManager.loadDevices(getContext());
        if(devices != null){
            for (BleDevice item:devices){
                Log.e("AOJ-BLE","My Devices="+item.toString());
                this.deviceAdapter.add(item);
            }
        }
        this.deviceAdapter.notifyDataSetChanged();
    }

    /**
     * Debug message
     * @param msg
     */
    private void debugMessage(String msg){
        Log.e(TAG,msg);
    }

    /**
     * 提示对话框
     * @param context
     * @param title
     * @param msg
     */
    public void showConfirmDialog(Context context, String title, String msg,BleDevice device)
    {
        new MaterialAlertDialogBuilder(context)
                .setTitle(title)
                .setMessage(msg)
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                })
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //删除设备
                        boolean isRemove = StoreManager.removeDevice(context, device);
                        if(isRemove){
                            deviceAdapter.remove(device);
                            deviceAdapter.notifyDataSetChanged();
                        }
                    }
                }).show();
    }

}