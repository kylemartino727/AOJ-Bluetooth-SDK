package com.aojmedical.devhelper.view;

import android.util.Log;

import com.aojmedical.devhelper.setting.IDialogActionListener;
import com.aojmedical.devhelper.setting.OnSettingItemListener;
import com.aojmedical.devhelper.setting.SettingItem;
import com.aojmedical.devhelper.setting.SettingOptions;
import com.aojmedical.devhelper.setting.SettingPanel;
import com.aojmedical.devhelper.utils.AppConfig;
import com.aojmedical.devhelper.utils.AppLogger;
import com.aojmedical.plugin.ble.AHDevicePlugin;
import com.aojmedical.plugin.ble.OnSettingListener;
import com.aojmedical.plugin.ble.data.po.AHSpO2Alarm;
import com.aojmedical.plugin.ble.data.po.AHSpO2AlarmSetting;
import com.aojmedical.plugin.ble.data.temp.AHTempCmd;
import com.aojmedical.plugin.ble.data.temp.AHTempMode;
import com.aojmedical.plugin.ble.data.temp.AHTempSetting;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SpO2AlarmView {

    public static boolean show(String deviceMac, OnSettingListener listener) {
        AHSpO2Alarm alarm = new AHSpO2Alarm();
        AHSpO2AlarmSetting setting = new AHSpO2AlarmSetting(alarm);
        SettingItem maxItem = new SettingItem("Max SpO2", SettingOptions.Number, new OnSettingItemListener() {
            @Override
            public void onValueChanged(SettingItem item, String value) {
                alarm.setMaxSpo2(Integer.parseInt(value));
            }
        });
        SettingItem minItem = new SettingItem("Min SpO2", SettingOptions.Number, new OnSettingItemListener() {
            @Override
            public void onValueChanged(SettingItem item, String value) {
                alarm.setMinSpo2(Integer.parseInt(value));
            }
        });
        SettingItem maxItem2 = new SettingItem("Max Pulse Rate", SettingOptions.Number, new OnSettingItemListener() {
            @Override
            public void onValueChanged(SettingItem item, String value) {
                alarm.setMaxPulseRate(Integer.parseInt(value));
            }
        });
        SettingItem minItem2 = new SettingItem("Min Pulse Rate", SettingOptions.Number, new OnSettingItemListener() {
            @Override
            public void onValueChanged(SettingItem item, String value) {
                alarm.setMinPulseRate(Integer.parseInt(value));
            }
        });

        List<SettingItem> items = new ArrayList<>();
        items.add(maxItem);
        items.add(minItem);
        items.add(maxItem2);
        items.add(minItem2);
        //show setting view
        SettingPanel.showSettingDialog("SpO2 Alarm", items, new IDialogActionListener() {
            @Override
            public void onSettingItems(List<SettingItem> items) {
                for (SettingItem item : items) {
                    if(item.getTextViewValue()!=null){
                        item.getListener().onValueChanged(item,item.getTextViewValue());
                    }
                }
                AppLogger.log(setting.toString());
                AHDevicePlugin.getInstance().pushSetting(deviceMac,setting,listener);
            }
        });
        return true;
    }
}
