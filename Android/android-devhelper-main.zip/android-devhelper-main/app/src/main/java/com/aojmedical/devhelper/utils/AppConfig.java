package com.aojmedical.devhelper.utils;


import com.aojmedical.plugin.ble.data.BTDeviceType;

public class AppConfig {

    /**
     * 扫描过滤
     */
    public static String[] SCAN_FILTER = new String[]{
            "All Devices",
            BTDeviceType.Thermometer.name(),
            BTDeviceType.Oximeter.name(),
            BTDeviceType.BloodPressureMeter.name(),
            BTDeviceType.DigitalThermometer.name(),
    };

    public static String[] TEMP_TYPE = new String[]{
            "°C",
            "°F",
    };

    public static String[] USER = new String[]{
            "All User",
            "User 1",
            "User 2",
    };

    public static String[] SWITCH_USER = new String[]{
            "User 1",
            "User 2",
    };

    public static String[] VOICE_CONTROL = new String[]{
            "Enable",
            "Disable",
    };
}
