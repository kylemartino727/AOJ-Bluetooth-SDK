package com.aojmedical.devhelper.view;

import android.app.Activity;
import android.text.TextUtils;
import android.util.Log;

import com.aojmedical.devhelper.model.ScanFilter;
import com.aojmedical.devhelper.setting.IDialogActionListener;
import com.aojmedical.devhelper.setting.OnSettingItemListener;
import com.aojmedical.devhelper.setting.SettingItem;
import com.aojmedical.devhelper.setting.SettingOptions;
import com.aojmedical.devhelper.setting.SettingPanel;
import com.aojmedical.devhelper.utils.AppConfig;
import com.aojmedical.devhelper.utils.AppUtils;
import com.aojmedical.plugin.ble.data.BTDeviceType;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ScanFilterView {

    public static boolean show(DeviceAdapter adapter,OnScanFilterListener listener){
        ScanFilter filter = new ScanFilter(AppConfig.SCAN_FILTER[0]);
        SettingPanel.showSingleChoiceDialog("Scan Filter", AppConfig.SCAN_FILTER, new IDialogActionListener() {
            @Override
            public void onSingleChoiceItemValue(int index) {
                if(index == 0){
                    listener.onScanFilter(BTDeviceType.Unknown);
                }
                else {
                    Log.e("Dev-BLE","scan filter >> "+BTDeviceType.getDeviceType(index));
                    listener.onScanFilter(BTDeviceType.getDeviceType(index));
                }
            }
        });
        return true;
    }

    private static  boolean showSetting(String title, List<SettingItem> items,ScanFilter filter)
    {
        //show setting view
        SettingPanel.showSettingDialog(title, items, new IDialogActionListener() {
            @Override
            public void onSettingItems(List<SettingItem> items) {
                for (SettingItem item : items) {
                    if(item.getTextViewValue()!=null){
                        item.getListener().onValueChanged(item,item.getTextViewValue());
                    }
                }
            }
        });
        return true;
    }
}
