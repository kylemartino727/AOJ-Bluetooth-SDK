///**
// *
// */
//package com.aojmedical.devhelper.chart;
//
//import java.util.ArrayList;
//import java.util.Calendar;
//import java.util.Collections;
//import java.util.Date;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//import java.util.Set;
//import java.util.concurrent.TimeUnit;
//
//import android.text.TextUtils;
//
//import com.bluetooth.demo.view.chart.TimeChartItem;
//import com.bluetooth.demo.view.data.BloodGlucoseAvgData;
//import com.lifesense.ble.bean.BloodGlucoseData;
//import com.lifesense.ble.tools.DateFormatUtils;
//
///**
// * @author sky
// *
// */
public class DeviceDataUtils {
//
//	private static Map<String, List<Object>>dataMap=new HashMap<String, List<Object>>();
//
//
//	public static void clearCacheData()
//	{
//		dataMap=new HashMap<String, List<Object>>();
//	}
//
//	public static List<Object> getDeviceMeasurementData(String broadcastID)
//	{
//		if(dataMap.size()==0)
//		{
//			return null;
//		}
//		return dataMap.get(getObjectKey(broadcastID));
//	}
//
//
//	public static void addDeviceMeasurementData(String broadcastId,Object obj)
//	{
//		List<Object> dataObjs=getDeviceMeasurementData(broadcastId);
//		if(dataObjs==null)
//		{
//			dataObjs=new ArrayList<Object>();
//		}
//		String key=getObjectKey(broadcastId);
//		dataObjs.add(obj);
//		//remove old obj
//		dataMap.remove(key);
//		//caching new data obj
//		dataMap.put(key, dataObjs);
//	}
//
//
//	private static String getObjectKey(String broadcastID)
//	{
//		if(TextUtils.isEmpty(broadcastID))
//		{
//			return broadcastID;
//		}
//
//		if(dataMap==null || dataMap.size()==0)
//		{
//			return broadcastID;
//		}
//		String targetKey=broadcastID;
//		Set<String> keys=dataMap.keySet();
//		for(String key:keys)
//		{
//			if(key!=null && key.equalsIgnoreCase(broadcastID))
//			{
//				targetKey=key;
//			}
//		}
//		return targetKey;
//	}
//
//
//	/**
//	 * 获取距离当前时间最近的30笔记录
//	 * @param datas
//	 * @param count
//	 * @return
//	 */
//	public static List<BloodGlucoseData> getLastDataWithCount(List<BloodGlucoseData> datas,int count){
//		if(datas==null || datas.size()==0){
//			return null;
//		}
//		if(datas.size() < count){
//			return datas;
//		}
//		//对数据进行降序排列，取前30笔记录
//		Collections.sort(datas,Collections.reverseOrder());
//		List<BloodGlucoseData> targetDatas=new ArrayList<BloodGlucoseData>();
//		for(int i=0;i<count;i++){
//			targetDatas.add(datas.get(i));
//		}
//		return targetDatas;
//	}
//
//	/**
//	 * 获取数据列表中，最小测量时间的对象
//	 * @param datas
//	 * @return
//	 */
//	public static long getMinMeasureDate(List<BloodGlucoseData> datas)
//	{
//		if(datas==null || datas.size()==0){
//			return 0;
//		}
//		//对数据进行排序
//		Collections.sort(datas);
//		//取第一个元素的时间
//		return datas.get(0).getUtc();
//	}
//
//
//	/**
//	 * 根据一组数据获取时间图表的X与Y值
//	 * @param datas
//	 * @param type
//	 * @return
//	 */
//	public static List<TimeChartItem> getTimeChartItem(int value,int type)
//	{
//		List<TimeChartItem> items=new ArrayList<TimeChartItem>();
////		// increment by 1 hour
////		long minUtc=DeviceDataUtils.getMinMeasureDate(datas);
////		float from=TimeUnit.MILLISECONDS.toHours(minUtc*1000);
////		//获取每天的平均值
////		List<BloodGlucoseAvgData> avgData=getAvgDataWithDay(datas);
////		if(avgData==null || avgData.size()==0){
////			return null;
////		}
////		long DAY_IN_MS = 1000 * 60 * 60 * 24;
////		Date mornDate=new Date(System.currentTimeMillis() + (1 * DAY_IN_MS));
////		Date agoDate=new Date(System.currentTimeMillis() - (6* 30 * DAY_IN_MS));
////
////		for(BloodGlucoseAvgData data:avgData){
////			long dataTime=data.getDate().getTime();
////			//过小未来数据
////			if(data.getDate()==null || dataTime > mornDate.getTime()){
////				continue;
////			}
////			TimeChartItem item=new TimeChartItem();
//////			item.setData(data);
////			float time=TimeUnit.MILLISECONDS.toHours(data.getDate().getTime());
////			item.setxValue(time);
////			item.setyValue(data.getAvgValue());
////			//add list
////			items.add(item);
////			from+=24;
////		}
//		return items;
//	}
//
//	/**
//	 * 获取数据列表中，最大测量时间的对象
//	 * @param datas
//	 * @return
//	 */
//	public static long getMaxMeasureDate(List<BloodGlucoseData> datas)
//	{
//		if(datas==null || datas.size()==0){
//			return 0;
//		}
//		//对数据进行排序
//		Collections.sort(datas,Collections.reverseOrder());
//		//取第一个元素的时间
//		return datas.get(0).getUtc();
//	}
//
//
//	/**
//	 * 根据指定天数，获取某段时间内的平均值
//	 * @param datas
//	 * @param avgType
//	 * @return
//	 */
//	public static int getAvgValue(List<BloodGlucoseData> datas,int avgType)
//	{
//		List<BloodGlucoseData> avgDatas=getDatasWithTime(datas, avgType);
//		if(avgDatas==null || avgDatas.size()==0){
//			return 0;
//		}
//		int value=0;
//		for(BloodGlucoseData data:avgDatas){
//			value+=data.getConcentration();
//		}
//		return value/avgDatas.size();
//	}
//
//
//	/**
//	 * 获取指定天数的数据列表
//	 * @param datas
//	 * @param avgType
//	 * @return
//	 */
//	public static List<BloodGlucoseData> getDatasWithTime(List<BloodGlucoseData> datas,int avgType)
//	{
//		if(datas==null || datas.size()==0){
//			return null;
//		}
//		//获取距离当前时间的指定天数的UTC
//		long DAY_IN_MS = 1000 * 60 * 60 * 24;
//		Date agoDate=new Date(System.currentTimeMillis() - (avgType * DAY_IN_MS));
//		long agoTime=agoDate.getTime()/1000;
//		//获取距离当前时间偏移一天的UTC
//		Date mornDate=new Date(System.currentTimeMillis() + (1 * DAY_IN_MS));
//		long mornTime=mornDate.getTime()/1000;
//		System.err.println("target time >> "+agoTime+"; date >> "+DateFormatUtils.defaultDateFormat.format(agoDate));
//		List<BloodGlucoseData> targetDatas=new ArrayList<BloodGlucoseData>();
//		for(BloodGlucoseData data:datas){
//
//			if(data.getUtc()==0){
//				continue;
//			}
//			if(data.getUtc() >=agoTime && data.getUtc() < mornTime)
//			{
//				System.err.println("target data >> "+data.getConcentration()+"; utc"+data.getUnit());
//				targetDatas.add(data);
//			}
//		}
//		return targetDatas;
//	}
//
//
//	/**
//	 * 判断是否是同一天的时间
//	 * @param date1
//	 * @param date2
//	 * @return
//	 */
//	private static boolean isSameDay(Date date1, Date date2)
//	{
//		Calendar calendar1 = Calendar.getInstance();
//		calendar1.setTime(date1);
//		Calendar calendar2 = Calendar.getInstance();
//		calendar2.setTime(date2);
//		boolean sameYear = calendar1.get(Calendar.YEAR) == calendar2.get(Calendar.YEAR);
//		boolean sameMonth = calendar1.get(Calendar.MONTH) == calendar2.get(Calendar.MONTH);
//		boolean sameDay = calendar1.get(Calendar.DAY_OF_MONTH) == calendar2.get(Calendar.DAY_OF_MONTH);
//		return (sameDay && sameMonth && sameYear);
//	}
//
//	/**
//	 * 获取相同时间的数据列表，以天为单位
//	 * @param datas
//	 * @param time
//	 * @return
//	 */
//	public static BloodGlucoseAvgData getSameDayDatas(List<BloodGlucoseData> datas,Date time){
//		if(datas==null || datas.size()==0 || time==null){
//			return null;
//		}
//		List<BloodGlucoseData> sameDayDatas=new ArrayList<BloodGlucoseData>();
//		int count=0;
//		for(BloodGlucoseData data:datas){
//			if(isSameDay(time, data.getMeasureDate())){
//				//add it to the same day list
//				sameDayDatas.add(data);
//				count+=data.getConcentration();
//			}
//		}
//		if(sameDayDatas==null || sameDayDatas.size()==0){
//			return null;
//		}
//		BloodGlucoseAvgData avgData=new BloodGlucoseAvgData();
//		avgData.setDate(time);
//		avgData.setSize(sameDayDatas.size());
//		avgData.setAvgValue((count/sameDayDatas.size()));
//		avgData.setSrcDatas(sameDayDatas);
//		return avgData;
//	}
//
//	/**
//	 * 获取不同天数的列表
//	 * @param datas
//	 * @return
//	 */
//	public static List<Date> getSameDateWithDay(List<BloodGlucoseData> datas){
//		if(datas==null || datas.size()==0){
//			return null;
//		}
//		//对数据进行排序
//		Collections.sort(datas);
//		//获取数组第一个元素的时间
//		Date firstDate=datas.get(0).getMeasureDate();
//		List<Date> dates=new ArrayList<Date>();
//		dates.add(firstDate);
//		//统计时间不同的天数
//		for(BloodGlucoseData data:datas){
//			if(!isSameDay(firstDate, data.getMeasureDate())){
//				firstDate=data.getMeasureDate();
//				dates.add(firstDate);
//			}
//		}
//		return dates;
//
//	}
//
//	public static List<BloodGlucoseAvgData> getAvgDataWithDay(List<BloodGlucoseData> datas){
//		if(datas==null || datas.size()==0){
//			return null;
//		}
//		List<BloodGlucoseAvgData> avgDatas=new ArrayList<BloodGlucoseAvgData>();
//		List<Date> dates=getSameDateWithDay(datas);
//		for(Date time:dates){
//			System.err.println("my same day time >> "+time);
//			//获取同一天数的数据平均值
//			BloodGlucoseAvgData avgData=getSameDayDatas(datas, time);
//			if(avgData!=null){
//				avgDatas.add(avgData);
//			}
//		}
//		return avgDatas;
//
//	}
//
//
}
