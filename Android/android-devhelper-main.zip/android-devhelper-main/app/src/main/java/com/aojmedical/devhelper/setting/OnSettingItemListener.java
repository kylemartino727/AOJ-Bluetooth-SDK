package com.aojmedical.devhelper.setting;


public interface OnSettingItemListener {

    void onValueChanged(SettingItem item, String value);
}
