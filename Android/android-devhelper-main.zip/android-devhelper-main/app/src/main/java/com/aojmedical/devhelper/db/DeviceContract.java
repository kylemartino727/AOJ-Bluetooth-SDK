package com.aojmedical.devhelper.db;

import android.provider.BaseColumns;

public class DeviceContract {

	// To prevent someone from accidentally instantiating the contract class,
	// make the constructor private.
	private DeviceContract() {}

	/* Inner class that defines the table contents */
	public static class DeviceEntry implements BaseColumns {
		public static final String TABLE_NAME = "aoj_devices";
		public static final String COLUMN_NAME_MAC = "mac";//不带符号
		public static final String COLUMN_NAME_NAME="name";
		public static final String COLUMN_NAME_TYPE="type";
		public static final String COLUMN_NAME_UTC="utc";

	}
}
