package com.aojmedical.devhelper.utils;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;
import com.aojmedical.devhelper.R;

public class PermissionUtils {

    public static final int PERMISSION_CODE = 30001;
    private static final String ENABLED_NOTIFICATION_LISTENERS = "enabled_notification_listeners";
    private static final String ACTION_NOTIFICATION_LISTENER_SETTINGS = "android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS";
    private static boolean hasTip = false;
    private static boolean hasRequest = false;

    private PermissionUtils() {
    }

    public static String[] getAllPermissions() {
        return new String[]{
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.BLUETOOTH_ADMIN,
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_CONNECT,

        };
    }

    public static void handleRequestFailed(Activity activity, String permission) {
        if (hasTip) {
            return;
        }
        hasTip = true;
        if (permission.equals(Manifest.permission.ACCESS_COARSE_LOCATION)) {
            DialogUtils.showToast(activity, activity.getString(R.string.perm_fail_location));
        } else if (permission.equals(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            DialogUtils.showToast(activity, activity.getString(R.string.perm_fail_readwrite));
        }  else if (permission.equals(Manifest.permission.BLUETOOTH_ADMIN)) {
            DialogUtils.showToast(activity, activity.getString(R.string.perm_fail_bluetooth));
        }
    }

    public static void checkAll(Activity activity) {
        for (String s : getAllPermissions()) {
            if (!checkPermission(activity, s)) {
                handleRequestFailed(activity, s);
            }
        }
    }

    public static void requestAll(Activity activity) {
        if (hasRequest) {
            checkAll(activity);
            return;
        }
        hasRequest = true;
        List<String> permissions = new ArrayList<>();
        for (String s : getAllPermissions()) {
            if (!checkPermission(activity, s)) {
                permissions.add(s);
            }
        }
        if (!permissions.isEmpty()) {
            String[] array = new String[permissions.size()];
            permissions.toArray(array);
            requestPermission(activity, array, PERMISSION_CODE);
        }
    }

    /**
     * 申请权限
     */
    public static void requestPermission(Activity activity, String[] permissions, int requestCode) {
        ActivityCompat.requestPermissions(activity, permissions, requestCode);
    }

    /**
     * 申请权限
     */
    public static void requestPermission(Activity activity, String permissions, int requestCode) {
        requestPermission(activity, new String[]{permissions}, requestCode);
    }

    public static boolean checkPermission(Context context, String permission) {
        return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED;
    }

    public static boolean hasBluetoothPermission() {
        return checkPermission(AppHolder.getContext(), Manifest.permission.BLUETOOTH);
    }

    /**
     * 检测系统的定位权限是否已打开或已授权
     * @return
     */
    public static boolean checkLocationPermission(Activity activity)
    {
        try{
            if(Build.VERSION.SDK_INT < 23){
                return true;
            }
            if (!(activity.getApplicationContext().checkSelfPermission
                    (android.Manifest.permission.ACCESS_FINE_LOCATION)== PackageManager.PERMISSION_GRANTED)){
                return false;
            }
            else{
                return true;
            }
        }
        catch(Exception e){
            e.printStackTrace();
            return true;
        }
    }

}
