package com.aojmedical.devhelper.view;

import android.util.Log;

import com.aojmedical.devhelper.setting.IDialogActionListener;
import com.aojmedical.devhelper.setting.OnSettingItemListener;
import com.aojmedical.devhelper.setting.SettingItem;
import com.aojmedical.devhelper.setting.SettingOptions;
import com.aojmedical.devhelper.setting.SettingPanel;
import com.aojmedical.devhelper.utils.AppConfig;
import com.aojmedical.devhelper.utils.AppLogger;
import com.aojmedical.devhelper.utils.AppUtils;
import com.aojmedical.plugin.ble.AHDevicePlugin;
import com.aojmedical.plugin.ble.OnSettingListener;
import com.aojmedical.plugin.ble.data.BTDeviceSyncSetting;
import com.aojmedical.plugin.ble.data.bpm.AHBpmConfig;
import com.aojmedical.plugin.ble.data.bpm.AHBpmConfigSetting;
import com.aojmedical.plugin.ble.data.bpm.AHBpmRemoveSetting;
import com.aojmedical.plugin.ble.data.bpm.AHBpmSyncSetting;
import com.aojmedical.plugin.ble.data.temp.AHTempCmd;
import com.aojmedical.plugin.ble.data.temp.AHTempMode;
import com.aojmedical.plugin.ble.data.temp.AHTempSetting;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class BpmSettingView {

    public static boolean showVoiceControl(String mac, OnSettingListener listener)
    {
        AHBpmConfigSetting setting = new AHBpmConfigSetting(AHBpmConfig.VoiceControl);
        SettingItem modeItem = new SettingItem("Voice Control", SettingOptions.SingleChoice, new OnSettingItemListener() {
            @Override
            public void onValueChanged(SettingItem item, String value) {
                setting.setVoiceState(item.getIndex() == 0);
            }
        });
        modeItem.setChoiceItems(Arrays.asList(AppConfig.VOICE_CONTROL));
        List<SettingItem> items = new ArrayList<>();
        items.add(modeItem);
        showSettingView("Voice Control",mac,setting,items,listener);
        return true;
    }


    public static boolean showSwitchUser(String mac, OnSettingListener listener) {
        AHBpmConfigSetting setting = new AHBpmConfigSetting(AHBpmConfig.SwitchUser);
        SettingItem modeItem = new SettingItem("User Switching", SettingOptions.SingleChoice, new OnSettingItemListener() {
            @Override
            public void onValueChanged(SettingItem item, String value) {
                setting.setUser(item.getIndex() + 1);
            }
        });
        modeItem.setChoiceItems(Arrays.asList(AppConfig.SWITCH_USER));
        List<SettingItem> items = new ArrayList<>();
        items.add(modeItem);
        showSettingView("Switch User",mac,setting,items,listener);
        return true;
    }

    public static boolean showUserDataSync(String mac, OnSettingListener listener) {
        AHBpmSyncSetting setting = new AHBpmSyncSetting(1);
        SettingItem modeItem = new SettingItem("User Data", SettingOptions.SingleChoice, new OnSettingItemListener() {
            @Override
            public void onValueChanged(SettingItem item, String value) {
                if(item.getIndex() == 0){
                    //sync all
                    setting.setSyncAll(true);
                }
                else{
                    setting.setUserNum(item.getIndex());
                }
            }
        });
        modeItem.setChoiceItems(Arrays.asList(AppConfig.USER));
        List<SettingItem> items = new ArrayList<>();
        items.add(modeItem);
        showSettingView("Sync User Data",mac,setting,items,listener);
        return true;
    }

    public static boolean showUserDataRemove(String mac, OnSettingListener listener) {
        AHBpmRemoveSetting setting = new AHBpmRemoveSetting(1);
        SettingItem modeItem = new SettingItem("User Data", SettingOptions.SingleChoice, new OnSettingItemListener() {
            @Override
            public void onValueChanged(SettingItem item, String value) {
                if(item.getIndex() == 0){
                    //sync all
                    setting.setRemoveAll(true);
                }
                else{
                    setting.setUserNum(item.getIndex());
                }
            }
        });
        modeItem.setChoiceItems(Arrays.asList(AppConfig.USER));
        List<SettingItem> items = new ArrayList<>();
        items.add(modeItem);
        showSettingView("Remove User Data",mac,setting,items,listener);
        return true;
    }

    public static boolean showSettingView(String title, String mac, BTDeviceSyncSetting setting,List<SettingItem> items, OnSettingListener listener){
        //show setting view
        SettingPanel.showSettingDialog(title, items, new IDialogActionListener() {
            @Override
            public void onSettingItems(List<SettingItem> items) {
                for (SettingItem item : items) {
                    if(item.getTextViewValue()!=null){
                        item.getListener().onValueChanged(item,item.getTextViewValue());
                    }
                }
                AppLogger.log(setting.toString()+"; cmdBytes="+ AppUtils.byte2hexString(setting.encodeCmdBytes()));
                AHDevicePlugin.getInstance().pushSetting(mac,setting,listener);
            }
        });
        return true;
    }
}
