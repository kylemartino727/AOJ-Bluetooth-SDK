package com.aojmedical.devhelper.model;

public class ScanFilter {

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ScanFilter(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "ScanFilter{" +
                "name='" + name + '\'' +
                '}';
    }
}
