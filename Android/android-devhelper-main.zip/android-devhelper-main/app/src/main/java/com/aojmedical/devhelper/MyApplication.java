/**
 *
 */
package com.aojmedical.devhelper;

import android.annotation.TargetApi;
import android.os.FileUtils;
import android.util.Log;

import androidx.multidex.MultiDexApplication;

import com.aojmedical.devhelper.utils.AppException;
import com.aojmedical.devhelper.utils.AppHolder;
import com.aojmedical.devhelper.utils.AppUtils;
import com.aojmedical.plugin.ble.AHDevicePlugin;

/**
 * @author sky
 *
 */
public class MyApplication extends MultiDexApplication {

    private static final String TAG = "Dev-BLE[APP]";
    private static final String LOG_PATH = "Aoj/log";

    @TargetApi(23)
    @Override
    public void onCreate() {
        super.onCreate();
        AppHolder.init(this);

        //init LSBluetoothManager
        AHDevicePlugin.getInstance().initPlugin(getApplicationContext());

        //register bluetooth state change receiver
        AHDevicePlugin.getInstance().registerReceiver(getApplicationContext());
        Log.e(TAG, "SDK Version:" + AHDevicePlugin.getInstance().getVersion());

        //enable file logging of SDK
        String logPath = AppUtils.createPortraitUrl(getApplicationContext(), LOG_PATH);
        AHDevicePlugin.getInstance().saveDebugMessage(true, logPath, AppUtils.getVersion(this));

        //register exception handler
        Thread.setDefaultUncaughtExceptionHandler(new AppException(getApplicationContext(),logPath));

        //debug
        AHDevicePlugin.getInstance().openDebugMode("plugin.debug");
    }


}
