package com.aojmedical.devhelper.view;

import com.aojmedical.plugin.ble.data.BTDeviceType;

public interface OnScanFilterListener {

    void onScanFilter(BTDeviceType devType);
}
