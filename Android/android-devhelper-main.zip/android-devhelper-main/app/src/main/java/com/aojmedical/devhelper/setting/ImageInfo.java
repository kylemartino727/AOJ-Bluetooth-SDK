package com.aojmedical.devhelper.setting;

import android.graphics.drawable.Drawable;

import java.io.File;

public class ImageInfo {

    private String loadLabel;
    private String filePath;
    private File file;
    private Drawable drawable;

    public Drawable getDrawable() {
        return drawable;
    }

    public void setDrawable(Drawable drawable) {
        this.drawable = drawable;
    }

    public File getFile() {
        return file;
    }

    public void setFile(File file) {
        this.file = file;
    }

    public String getLoadLabel() {
        return loadLabel;
    }

    public void setLoadLabel(String loadLabel) {
        this.loadLabel = loadLabel;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    @Override
    public String toString() {
        return "ImageInfo{" +
                "loadLabel='" + loadLabel + '\'' +
                ", filePath='" + filePath + '\'' +
                '}';
    }
}
