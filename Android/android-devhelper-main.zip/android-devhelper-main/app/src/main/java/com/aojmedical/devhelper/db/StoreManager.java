package com.aojmedical.devhelper.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.aojmedical.devhelper.model.BleDevice;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;


public class StoreManager {

	private static SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss yyyy/MM/dd", Locale.getDefault());


	/**
	 * Save Device
	 * @return
	 */
	public static int saveDevice(Context appContext, BleDevice device){
		if(device==null){
			return 0;
		}
		if(checkDevice(appContext,device)){
			return 1;
		}
		String deviceMac=device.getMac().replace(":","").toUpperCase();
		DeviceHelper mDbHelper = new DeviceHelper(appContext);
		// Gets the data repository in write mode
		SQLiteDatabase db = mDbHelper.getWritableDatabase();
		long newRowId=0;
		// Create a new map of values, where column names are the keys
		ContentValues values = new ContentValues();
		values.put(DeviceContract.DeviceEntry.COLUMN_NAME_MAC,deviceMac);
		values.put(DeviceContract.DeviceEntry.COLUMN_NAME_NAME, device.getName());
		values.put(DeviceContract.DeviceEntry.COLUMN_NAME_TYPE, String.format("%d",device.getType()));
		values.put(DeviceContract.DeviceEntry.COLUMN_NAME_UTC,System.currentTimeMillis());

		// Insert the new row, returning the primary key value of the new row
		newRowId= db.insert(DeviceContract.DeviceEntry.TABLE_NAME, null, values);
		db.close();
		return (int)newRowId;
	}

	/**
	 * 判断设备是否已存在
	 * @return
	 */
	public static boolean checkDevice(Context appContext,BleDevice device)
	{
		String deviceMac=device.getMac().replace(":","").toUpperCase();
		DeviceHelper mDbHelper = new DeviceHelper(appContext);
		SQLiteDatabase db = mDbHelper.getReadableDatabase();
		// Define a projection that specifies which columns from the database
		// you will actually use after this query.
		String[] projection = new String[]{};//get all

		// Filter results WHERE "title" = 'My Title'
		String selection = DeviceContract.DeviceEntry.COLUMN_NAME_MAC + " = ? ";
		String[] selectionArgs = { deviceMac };
		// How you want the results sorted in the resulting Cursor
		String sortOrder =
				DeviceContract.DeviceEntry.COLUMN_NAME_UTC + " DESC";
		Cursor cursor = db.query(
				DeviceContract.DeviceEntry.TABLE_NAME, // The table to query
				projection,               // The array of columns to return (pass null to get all)
				selection,              // The columns for the WHERE clause
				selectionArgs,           // The values for the WHERE clause
				null,               // don't group the rows
				null,                // don't filter by row groups
				sortOrder                   // The sort order
		);
		if(cursor == null){
			return false;
		}
		boolean mark =  cursor.moveToNext();
		cursor.close();
		return mark;
	}


	/**
	 * Query Sleep Data With Device's MAC
	 * @return
	 */
	public static List<BleDevice> loadDevices(Context appContext){
		if(appContext == null){
			return null;
		}
		DeviceHelper mDbHelper = new DeviceHelper(appContext);
		SQLiteDatabase db = mDbHelper.getReadableDatabase();

		// Define a projection that specifies which columns from the database
		// you will actually use after this query.
		String[] projection = null;//get all

		// Filter results WHERE "title" = 'My Title'
		String selection = DeviceContract.DeviceEntry.COLUMN_NAME_MAC + " = ? ";
		String[] selectionArgs = null;//{ deviceMac };
		// How you want the results sorted in the resulting Cursor
		String sortOrder =
				DeviceContract.DeviceEntry.COLUMN_NAME_UTC + " DESC";
		Cursor cursor = db.query(
				DeviceContract.DeviceEntry.TABLE_NAME, // The table to query
				null,               // The array of columns to return (pass null to get all)
				null,              // The columns for the WHERE clause
				null,           // The values for the WHERE clause
				null,               // don't group the rows
				null,                // don't filter by row groups
				sortOrder                   // The sort order
				);
		if(cursor==null){
			return null;
		}
		List<BleDevice> items = new ArrayList<BleDevice>();
		while(cursor.moveToNext()) 
		{
			int macIndex=cursor.getColumnIndexOrThrow(DeviceContract.DeviceEntry.COLUMN_NAME_MAC);
			int utcIndex=cursor.getColumnIndexOrThrow(DeviceContract.DeviceEntry.COLUMN_NAME_UTC);
			int nameIndex=cursor.getColumnIndexOrThrow(DeviceContract.DeviceEntry.COLUMN_NAME_NAME);
			int typeIndex=cursor.getColumnIndexOrThrow(DeviceContract.DeviceEntry.COLUMN_NAME_TYPE);

			BleDevice data=new BleDevice();
			data.setMac(cursor.getString(macIndex));
			data.setName(cursor.getString(nameIndex));
			data.setType(Integer.parseInt(cursor.getString(typeIndex)));
			//data.setUtc(cursor.getInt(utcIndex));
			//add list
			items.add(data);
		}
		cursor.close();
		db.close();
		return items;
	}


	/**
	 * 删除设备
	 * @param appContext
	 * @param device
	 */
	public static boolean removeDevice(Context appContext,BleDevice device){
		if(appContext == null || device == null){
			return false;
		}
		try{
			String whereClause = DeviceContract.DeviceEntry.COLUMN_NAME_MAC + " = ? ";
			String[] whereArgs = {device.getMac()};
			DeviceHelper mDbHelper = new DeviceHelper(appContext);
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			boolean state =  db.delete(DeviceContract.DeviceEntry.TABLE_NAME,whereClause,whereArgs) > 0;
			db.close();
			return state;
		}
		catch (Exception e){
			e.printStackTrace();
			return false;
		}
	}
	



	private static Date toMeasureDate(String time){
		if(time==null || time.length()==0){
			return null;
		}
		try {
			return dateFormat.parse(time);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	
	public static String toStorageTime(int utc){
		try {
			return dateFormat.format(new Date(utc*1000L));
		} catch (Exception e) {
			e.printStackTrace();
			return "---";
		}
	}
}
