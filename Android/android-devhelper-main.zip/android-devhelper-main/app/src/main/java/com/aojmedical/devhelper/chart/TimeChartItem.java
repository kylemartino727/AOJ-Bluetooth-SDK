package com.aojmedical.devhelper.chart;


public class TimeChartItem {

	private float xValue;
	private int yValue;
	public float getxValue() {
		return xValue;
	}
	public void setxValue(float xValue) {
		this.xValue = xValue;
	}
	public int getyValue() {
		return yValue;
	}
	public void setyValue(int yValue) {
		this.yValue = yValue;
	}

	@Override
	public String toString() {
		return "TimeChartItem [xValue=" + xValue + ", yValue=" + yValue
				+ "]";
	}
	
	
	
}
