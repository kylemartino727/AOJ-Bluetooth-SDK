package com.aojmedical.devhelper;

import android.Manifest;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.aojmedical.devhelper.databinding.FragmentAddBinding;
import com.aojmedical.devhelper.db.StoreManager;
import com.aojmedical.devhelper.model.BleDevice;
import com.aojmedical.devhelper.utils.AppUtils;
import com.aojmedical.devhelper.utils.DialogUtils;
import com.aojmedical.devhelper.utils.PermissionUtils;
import com.aojmedical.devhelper.view.DeviceAdapter;
import com.aojmedical.devhelper.view.OnScanFilterListener;
import com.aojmedical.devhelper.view.ScanFilterView;
import com.aojmedical.plugin.ble.AHDevicePlugin;
import com.aojmedical.plugin.ble.OnSearchingListener;
import com.aojmedical.plugin.ble.data.BTDeviceInfo;
import com.aojmedical.plugin.ble.data.BTDeviceType;
import com.aojmedical.plugin.ble.data.BTScanFilter;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class AddDeviceFragment extends Fragment {

    private static final String TAG = "DevHelper";

    private FragmentAddBinding binding;
    private FloatingActionButton fab;
    private boolean isScanning;
    private ListView listView;
    private DeviceAdapter deviceAdapter;
    private ArrayList<BleDevice> bleDevices;
    private int countOfDevices;
    private TextView tvDevicesCount;
    private Handler mainHandler;
    private BTDeviceType filterType;
    private ProgressBar mProgressBar;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        if(getArguments().get(BleDevice.KEY) != null){
            BleDevice device = (BleDevice) getArguments().get(BleDevice.KEY);
            debugMessage("AddDeviceFragment >> "+device.toString());
        }
        this.isScanning = false;
        this.filterType = BTDeviceType.Unknown;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        binding = FragmentAddBinding.inflate(inflater, container, false);
        this.mainHandler = new Handler(getActivity().getMainLooper());
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.fab = (FloatingActionButton) getActivity().findViewById(R.id.fab);
        this.fab.setVisibility(View.VISIBLE);
        fab.setImageResource(!this.isScanning ?
                android.R.drawable.ic_menu_search : android.R.drawable.ic_menu_close_clear_cancel);
        this.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isScanning){
                    //stop searching
                    stopSearch();
                    isScanning = !isScanning;
                    fab.setImageResource(!isScanning ?
                            android.R.drawable.ic_menu_search : android.R.drawable.ic_menu_close_clear_cancel);
                }
                else{
                    //start searching
                    isScanning =  startSearch();
                    fab.setImageResource(!isScanning ?
                            android.R.drawable.ic_menu_search : android.R.drawable.ic_menu_close_clear_cancel);
                }
            }
        });
        //init view
        initView(view);
        //启动搜索
        this.autoSearch();
    }


    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        inflater.inflate(R.menu.menu_add, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_scan_filter) {
            return ScanFilterView.show(this.deviceAdapter, new OnScanFilterListener() {
                @Override
                public void onScanFilter(BTDeviceType devType) {
                    filterType = devType;
                    //clear
                    String str = "filter type="+devType.getValue()+"["+devType.name()+"]";
                    AddDeviceFragment.this.tvDevicesCount.setText("Scanning...");
                    deviceAdapter.clear();
                    deviceAdapter.notifyDataSetChanged();
                }
            });
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    /**
     * Jump To Connect View
     * @param view
     */
    private void initView(View view) {
        this.tvDevicesCount = view.findViewById(R.id.tv_scan_count);
        this.tvDevicesCount.setVisibility(View.GONE);
        this.mProgressBar = view.findViewById(R.id.scanning_progress_bar);
        this.mProgressBar.setVisibility(View.GONE);
        this.listView = view.findViewById(R.id.list_scan_devices);
        this.bleDevices = new ArrayList<>();
        this.deviceAdapter = new DeviceAdapter(this.getContext(),bleDevices);
        this.listView.setAdapter(this.deviceAdapter);
        this.listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                debugMessage("onItemClick >> "+bleDevices.get(position).toString());
                jumpToConnectView(bleDevices.get(position));
            }
        });
    }

    /**
     * Debug message
     * @param msg
     */
    private void debugMessage(String msg){
        Log.e(TAG,msg);
    }



    /**
     * Stop Search
     */
    private boolean stopSearch() {
        debugMessage("stopSearch....");
        this.mProgressBar.setVisibility(View.INVISIBLE);
        return AHDevicePlugin.getInstance().stopSearch();
    }

    /**
     * Start Search
     */
    private boolean startSearch() {
        if(!checkPermission()){
            debugMessage("no permission to start search....");
            return false;
        }
        debugMessage("startSearch....");
        //clear
        this.deviceAdapter.clear();
        this.mProgressBar.setVisibility(View.VISIBLE);
        this.tvDevicesCount.setVisibility(View.VISIBLE);
        this.tvDevicesCount.setText("Scanning...");
        List<BTDeviceType> types = new ArrayList<>();
        types.add(BTDeviceType.Oximeter);
        BTScanFilter filter = new BTScanFilter(types);
        return AHDevicePlugin.getInstance().searchDevice(null, new OnSearchingListener() {
            @Override
            public void onSearchResults(BTDeviceInfo btDevice) {
                //更新列表
                updateView(AppUtils.toBleDevice(btDevice));
            }
        });
    }

    /**
     * 更新视图
     * @param device
     */
    private void updateView(BleDevice device) {
        this.mainHandler.post(new Runnable() {
            @Override
            public void run() {
                if(filterType != BTDeviceType.Unknown
                        && device.getType() != filterType.getValue() ){
                    Log.e("Dev-BLE","scanResults >> "+device.toString()+"; filter="+filterType);
                    //已过滤，不显示
                    return;
                }
                int index = isDeviceExists(device);
                if(index != -1){
                    //update rssi
                    updateRssi(device.getRssi(),index);
                }
                else {
                    if(device != null){
                        deviceAdapter.add(device);
                        deviceAdapter.notifyDataSetChanged();
                    }
                    if(tvDevicesCount.getVisibility() == View.GONE){
                        tvDevicesCount.setVisibility(View.VISIBLE);
                    }
                    String str = String.format("Devices:%d",deviceAdapter.getCount());
                    AddDeviceFragment.this.tvDevicesCount.setText(str);
                }
            }
        });
    }

    /**
     * 更新设备信号
     * @param rssi
     */
    private void updateRssi(int rssi,int index) {
        this.mainHandler.post(new Runnable() {
            @Override
            public void run() {
                View v = listView.getChildAt(index);
                if(v == null)
                    return;
                TextView rssiText = (TextView) v.findViewById(R.id.tv_device_rssi);
                if(rssiText != null){
                    rssiText.setText(String.format("%d",rssi));
                    rssiText.setTextColor(Color.RED);
                }
                else {
                    Log.e(TAG,"failed to update device rssi="+rssi);
                }
            }
        });
    }


    /**
     * 判断设备是否已存在
     * @return
     */
    private int isDeviceExists(BleDevice device){
        for(BleDevice item:this.deviceAdapter.getDataSources()){
            if(item.getMac().equalsIgnoreCase(device.getMac())){
              return this.deviceAdapter.getPosition(item);
            }
        }
        return -1;
    }


    /**
     * 界面跳转
     * @param device
     */
    private void jumpToConnectView(BleDevice device){
        //stop search
        stopSearch();
        //保存设备信息
        StoreManager.saveDevice(getContext(),device);
        Bundle args = new Bundle();
        args.putParcelable(BleDevice.KEY,device);
        NavHostFragment.findNavController(AddDeviceFragment.this)
                .navigate(R.id.action_to_connect_fragment,args);
    }

    /**
     * 扫描权限检测
     * @return
     */
    private boolean checkPermission(){
        if(!AHDevicePlugin.getInstance().isSupportBLE()){
            DialogUtils.showDialog(getContext(),"Prompt", "Not support Bluetooth Low Energy");
            return false;
        }
        if(!AHDevicePlugin.getInstance().isBluetoothAvailable()){
            DialogUtils.showDialog(getContext(),"Prompt", "Please turn on Bluetooth");
            return false;
        }
        else if(!PermissionUtils.checkLocationPermission(getActivity())){
            ActivityCompat.requestPermissions(getActivity(),
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 0);
            return false;
        }
        return true;
    }

    /**
     * 自动搜索
     */
    private void  autoSearch(){
        //start searching
        isScanning =  startSearch();
        fab.setImageResource(!isScanning ?
                android.R.drawable.ic_menu_search : android.R.drawable.ic_menu_close_clear_cancel);

    }
}