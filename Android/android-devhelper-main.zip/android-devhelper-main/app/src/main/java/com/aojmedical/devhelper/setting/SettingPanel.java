package com.aojmedical.devhelper.setting;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.aojmedical.devhelper.utils.AppHolder;

import java.util.ArrayList;
import java.util.List;
import com.aojmedical.devhelper.R;

public class SettingPanel {

    protected static Context baseContext = AppHolder.getContext();
    private static EditText currentEditView;
    private static AlertDialog dialog;
    private static int lastGroupIndex = 0;

    public static void init(Context context){
        baseContext = context;
    }


    /**
     * Single Choice Dialog View
     */
    public static void showSingleChoiceDialog(String title, CharSequence[] items, final IDialogActionListener listener) {
        if (items == null || baseContext == null) {
            return;
        }
        ContextThemeWrapper ctw = new ContextThemeWrapper(baseContext, android.R.style.Theme_Holo_Light);
        // Strings to Show In Dialog with Radio Buttons
        // Creating and Building the Dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(ctw);
        builder.setTitle(title);
        builder.setSingleChoiceItems(items, -1, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                listener.onSingleChoiceItemValue(which);
                dialog.dismiss();
            }
        });
        dialog = builder.create();
        dialog.show();
    }

    /**
     * Single Choice Dialog View
     */
    private static void showMultiChoiceDialog(String title, CharSequence[] items, final IDialogActionListener listener) {
        if (items == null || baseContext == null) {
            return;
        }
        final List<Integer> pages = new ArrayList<Integer>();
        ContextThemeWrapper ctw = new ContextThemeWrapper(baseContext, android.R.style.Theme_Holo_Light);
        // Strings to Show In Dialog with Radio Buttons
        // Creating and Building the Dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(ctw);
        builder.setTitle(title);
        builder.setMultiChoiceItems(items, null, new AlertDialog.OnMultiChoiceClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which, boolean isChecked) {
                if (isChecked) {
                    pages.add(which);
                }
                else {
                    pages.remove(which);
                        }
                    }
        }).setPositiveButton("OK", new AlertDialog.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                listener.onMultiChoiceItemValue(pages);
                dialog.dismiss();
            }
        });
        dialog = builder.create();
        dialog.show();
    }


    /**
     * 展示设备功能设置项
     *
     * @param title
     * @param items
     * @param listener
     */
    public static void showSettingDialog(String title, List<SettingItem> items, final IDialogActionListener listener) {
        currentEditView = null;
        final List<SettingItem> settings = new ArrayList<SettingItem>();
        for (SettingItem item : items) {
            if (item.getOptions() != SettingOptions.Text) {
                settings.add(item);
            }
        }
        final List<SettingItem> editSettings = new ArrayList<SettingItem>();
        ContextThemeWrapper ctw = new ContextThemeWrapper(baseContext, android.R.style.Theme_Holo_Light);
        // Strings to Show In Dialog with Radio Buttons
        // Creating and Building the Dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(ctw);
        builder.setTitle(title);
        //add timepicker
        final View dialogView = LayoutInflater.from(baseContext).inflate(R.layout.function_list, null);
        LinearLayout layout = (LinearLayout) dialogView.findViewById(R.id.functions_list_layout);
        //初始化function list
        final ExpandableListView expandableListView = (ExpandableListView) dialogView.findViewById(R.id.device_functions_list);
        //初始化EditTextView
        initEditTextView(layout, items, expandableListView, new OnEditTextViewListener() {
            @Override
            public void onEditTextResults(EditText editView, SettingItem item) {
                currentEditView = editView;
                if (!editSettings.contains(item)) {
                    editSettings.add(item);
                }
            }
        });
        //init list adapter
        final SettingAdapter expandableListAdapter = new SettingAdapter(baseContext, settings);
        expandableListView.setAdapter(expandableListAdapter);
        expandableListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {
            @Override
            public void onGroupExpand(int groupPosition) {
                //collapse the old expanded group, if not the same
                //as new group to expand
                if (groupPosition != lastGroupIndex && lastGroupIndex != -1) {
                    //update item value
                    expandableListAdapter.notifyDataSetChanged();
                    expandableListView.collapseGroup(lastGroupIndex);
                }
                lastGroupIndex = groupPosition;
                //隐藏输入键盘及去除焦点
                if (currentEditView != null) {
                    //获取当前文本的输入内容
                    InputMethodManager imm = (InputMethodManager) baseContext.getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(currentEditView.getWindowToken(), 0);
                    currentEditView = null;
                }
            }
        });
        //重点击事件
        expandableListView.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {
            @Override
            public void onGroupCollapse(int groupPosition) {
                //update item value
                expandableListAdapter.notifyDataSetChanged();
                for (SettingItem item : settings) {
                    if (item.getOptions() == SettingOptions.SingleChoice) {
                        listener.onSingleChoiceItemValue(item.getIndex());
                    }
                }
            }
        });

        //set click listener
        builder.setPositiveButton("OK", new AlertDialog.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (lastGroupIndex != -1) {
                    //update item value
                    expandableListAdapter.notifyDataSetChanged();
                    expandableListView.collapseGroup(lastGroupIndex);
                    lastGroupIndex = -1;
                }
                //回调设置信息
                List<SettingItem> results = new ArrayList<SettingItem>();
                results.addAll(settings);
                results.addAll(editSettings);
                listener.onSettingItems(results);
                dialog.dismiss();
            }
        });
        dialog = builder.setView(dialogView).create();
        dialog.show();
    }


    /**
     * 根据设置项，初始化EditText View
     *
     * @param items
     * @param listView
     */
    private static void initEditTextView(LinearLayout layout, List<SettingItem> items, final ExpandableListView listView, final OnEditTextViewListener listener) {
        List<SettingItem> editItems = getEditSettingItem(items);
        if (editItems == null || editItems.size() == 0) {
            return;
        }
        for (final SettingItem item : editItems) {
            //add edit text cell
            LayoutInflater layoutInflater = (LayoutInflater) baseContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View editCellView = layoutInflater.inflate(R.layout.setting_item, null);
            TextView titleView = (TextView) editCellView.findViewById(R.id.setting_title_text_view);
            titleView.setText(item.getTitle());

            final EditText editView = (EditText) editCellView.findViewById(R.id.edit_text_view);
            editView.setInputType(item.getInputType());//InputType.TYPE_CLASS_TEXT
            final TextView valueTextView = (TextView) editCellView.findViewById(R.id.setting_value_text_view);
            editView.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                }

                @Override
                public void afterTextChanged(Editable s) {
                    if (s != null && s.length() > 0) {
                        String editValue = editView.getText().toString().trim();
                        valueTextView.setText(editValue);
                        //更新内容
                        item.setEditValue(editValue);
                        item.setTextViewValue(editValue);
                        //回调文本内容
                        listener.onEditTextResults(editView, item);
                    }
                }
            });
            //			editView.setOnFocusChangeListener(focusChangeListener);
            editCellView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (lastGroupIndex != -1) {
                        listView.collapseGroup(lastGroupIndex);
                        lastGroupIndex = -1;
                    }
                    listener.onEditTextResults(editView, item);
                    valueTextView.setVisibility(View.GONE);
                    editView.setVisibility(View.VISIBLE);
                    editView.setEnabled(true);
                    editView.setHint("please enter");
                    editView.requestFocus();
                    //弹出系统输入键盘
                    InputMethodManager imm = (InputMethodManager) baseContext.getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.showSoftInput(editView, InputMethodManager.SHOW_IMPLICIT);
                }
            });
            if(item.getTextViewValue()!=null && item.isShowText()){
                editView.setText(item.getTextViewValue());
                valueTextView.setText(item.getTextViewValue());
                valueTextView.setVisibility(View.VISIBLE);
            }
            layout.addView(editCellView);
        }
    }

    /**
     * 判断是否存在设置项
     *
     * @param items
     * @return
     */
    private static List<SettingItem> getEditSettingItem(List<SettingItem> items) {
        if (items == null || items.size() == 0) {
            return null;
        }
        List<SettingItem> editItems = new ArrayList<SettingItem>();
        for (SettingItem item : items) {
            if (item.getOptions() == SettingOptions.Text) {
                editItems.add(item);
            }
        }
        return editItems;
    }
}
