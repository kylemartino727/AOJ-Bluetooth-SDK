package com.aojmedical.devhelper.view;

import android.util.Log;

import com.aojmedical.devhelper.setting.IDialogActionListener;
import com.aojmedical.devhelper.setting.OnSettingItemListener;
import com.aojmedical.devhelper.setting.SettingItem;
import com.aojmedical.devhelper.setting.SettingOptions;
import com.aojmedical.devhelper.setting.SettingPanel;
import com.aojmedical.devhelper.utils.AppConfig;
import com.aojmedical.devhelper.utils.AppLogger;
import com.aojmedical.plugin.ble.AHDevicePlugin;
import com.aojmedical.plugin.ble.OnSettingListener;
import com.aojmedical.plugin.ble.data.temp.AHTempCmd;
import com.aojmedical.plugin.ble.data.temp.AHTempMode;
import com.aojmedical.plugin.ble.data.temp.AHTempSetting;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ModeConfigView {

    public static boolean show(String deviceMac, OnSettingListener listener){
        AHTempSetting setting = new AHTempSetting(AHTempCmd.ConfigMode);
        List<String> modes = new ArrayList<>();
        for (AHTempMode mode:AHTempMode.values()){
            if(mode != AHTempMode.Unknown){
                modes.add(mode.toString());
            }
        }
        SettingItem modeItem = new SettingItem("Measuring Mode", SettingOptions.SingleChoice, new OnSettingItemListener() {
            @Override
            public void onValueChanged(SettingItem item, String value) {
                setting.setMode(AHTempMode.valueOf(value));
            }
        });
        modeItem.setChoiceItems(modes);

        SettingItem typeItem = new SettingItem("Temperature Unit", SettingOptions.SingleChoice, new OnSettingItemListener() {
            @Override
            public void onValueChanged(SettingItem item, String value) {
                setting.setUnit(item.getIndex());
            }
        });
        typeItem.setChoiceItems(Arrays.asList(AppConfig.TEMP_TYPE));

        List<SettingItem> items = new ArrayList<>();
        items.add(modeItem);
        items.add(typeItem);
        //show setting view
        SettingPanel.showSettingDialog("Mode Config", items, new IDialogActionListener() {
            @Override
            public void onSettingItems(List<SettingItem> items) {
                for (SettingItem item : items) {
                    if(item.getTextViewValue()!=null){
                        item.getListener().onValueChanged(item,item.getTextViewValue());
                    }
                }
                AppLogger.log(setting.toString());
                AHDevicePlugin.getInstance().pushSetting(deviceMac,setting,listener);
            }
        });
        return true;
    }
}
