package com.aojmedical.devhelper.utils;

import android.annotation.SuppressLint;
import android.content.Context;

import java.util.logging.Handler;

public class AppHolder {


    @SuppressLint("StaticFieldLeak")
    private static Context mContext;

    private AppHolder() {
    }

    public static void init(Context context) {
        mContext = context.getApplicationContext();
    }

    public static Context getContext() {
        return mContext;
    }

}
