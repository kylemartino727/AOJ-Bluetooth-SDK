package com.aojmedical.devhelper.model;

import android.os.Parcel;
import android.os.Parcelable;

public class BleDevice implements Parcelable {

    public static final String KEY = "com.aojmedical.devhelper.model.BleDevice";

    private String name;
    private String mac;
    private int rssi;
    private int type;

    /**
     * 设备来源
     */
    private int source;


    protected BleDevice(Parcel in) {
        name = in.readString();
        mac = in.readString();
        rssi = in.readInt();
        type = in.readInt();
        source = in.readInt();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMac() {
        return mac;
    }

    public void setMac(String mac) {
        this.mac = mac;
    }

    public int getRssi() {
        return rssi;
    }

    public void setRssi(int rssi) {
        this.rssi = rssi;
    }

    public int getType() {
        return type;
    }

    public void setType(int typeStr) {
        this.type = typeStr;
    }

    public int getSource() {
        return source;
    }

    public void setSource(int source) {
        this.source = source;
    }

    @Override
    public String toString() {
        return "BleDevice{" +
                ", name='" + name + '\'' +
                ", mac='" + mac + '\'' +
                ", rssi=" + rssi +
                ", type=" + type +
                '}';
    }

    public BleDevice() {
        this.name = "Name";
        this.mac = "EF:21:37:B2:93:A8";
        this.rssi = -37;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(name);
        parcel.writeString(mac);
        parcel.writeInt(rssi);
        parcel.writeInt(type);
        parcel.writeInt(source);
    }

    public static final Creator<BleDevice> CREATOR = new Creator<BleDevice>() {
        @Override
        public BleDevice createFromParcel(Parcel in) {
            return new BleDevice(in);
        }

        @Override
        public BleDevice[] newArray(int size) {
            return new BleDevice[size];
        }
    };
}
